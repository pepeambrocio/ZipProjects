import React, { useState } from "react";
import { Form, Button, Row, Col } from "react-bootstrap";
import Logo from "../components/EsiLogo";

const UserForm = (props) => {
  const [state, setState] = useState({
    email: "",
    prescriptionNumber: "",
    birthDate: "",
  });

  const handleOnSubmit = (event) => {
    event.preventDefault();
    props.history.push({
      pathname: "/details",
      state,
    });
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setState((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  return (
    <div>
      <Row className="justify-content-md-center">
        <Col xs={12} sm={4} md={4}>
          <Logo />
        </Col>
      </Row>
      <Form className="register-form" onSubmit={handleOnSubmit}>
        <Form.Group controlId="email">
          <Form.Label>Email</Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter email"
            name="email"
            onChange={handleInputChange}
            value="jcruz@express-scripts.com"
            readOnly
          />
        </Form.Group>
        <Form.Group controlId="prescriptionNumber">
          <Form.Label>Prescription number</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter Prescription number"
            name="prescriptionNumber"
            onChange={handleInputChange}
          />
        </Form.Group>
        <Form.Group controlId="birthDate">
          <Form.Label>Birth date</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter Birth date"
            name="birthDate"
            onChange={handleInputChange}
          />
        </Form.Group>
        <Button variant="primary" type="submit">
          Register
        </Button>
      </Form>
    </div>
  );
};

export default UserForm;
