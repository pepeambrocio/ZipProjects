import React, { useState } from "react";
import { Form, Button, Row, Col } from "react-bootstrap";
import { useLocation } from "react-router-dom";
import Logo from "../components/EsiLogo";
import styled from "styled-components";

function useQuery() {
  return new URLSearchParams(useLocation().search);
}

const StyledTitle = styled.h1`
  font-size: 3.1rem;
  line-height: 1.2;
  color: #13568c;
  font-weight: 400 !important;
`;

const ProductDevice01 = styled.div`
  position: absolute;
  right: 5%;
  bottom: -30%;
  width: 300px;
  height: 540px;
  background-color: #13568c;
  border-radius: 21px;
  -webkit-transform: rotate(30deg);
  transform: rotate(30deg);
  &:before {
    position: absolute;
    top: 10%;
    right: 10px;
    bottom: 10%;
    left: 10px;
    content: "";
    background-color: rgba(255, 255, 255, 0.1);
    border-radius: 5px;
    box-sizing: border-box;
  }
`;

const ProductDevice02 = styled.div`
  top: -25%;
  position: absolute;
  right: auto;
  bottom: 0;
  left: 5%;
  width: 300px;
  height: 540px;
  background-color: #13568c;
  border-radius: 21px;
  -webkit-transform: rotate(30deg);
  transform: rotate(30deg);
  &:before {
    position: absolute;
    top: 10%;
    right: 10px;
    bottom: 10%;
    left: 10px;
    content: "";
    background-color: rgba(255, 255, 255, 0.1);
    border-radius: 5px;
    box-sizing: border-box;
  }
`;

const ContentImage = styled.div`
  overflow: hidden;
`;

const Home = (props) => {
  const [state, setState] = useState({
    token: "",
    email: "",
  });

  const handleOnSubmit = (event) => {
    event.preventDefault();
    props.history.push({
      pathname: "/userform",
      state,
    });
  };

  let query = useQuery();
  console.log(query);
  return (
    <div>
      <Row>
        <Col>
          <Form className="register-form" onSubmit={handleOnSubmit}>
            <ContentImage className="position-relative p-3 p-md-5 m-md-3 text-center">
              <ProductDevice01 dshadow-sm d-none d-md-block />
              <ProductDevice02 dshadow-sm d-none d-md-block />
              <div className="col-md-5 p-lg-5 mx-auto my-5">
                <StyledTitle className="mb-4">
                  Schedule your refill online
                </StyledTitle>
                <p className="lead font-weight-normal mb-5">
                  To get started you will need a 7 digit prescription number
                </p>
                <Button variant="primary" type="submit">
                  Register
                </Button>
              </div>
            </ContentImage>
          </Form>
        </Col>
      </Row>
      <Row>
        <Col xs={12} sm={4} md={4}>
          <div className="d-flex flex-column">
            <footer className="footer">
              <div>
                <span>&copy; 2020 Express Scripts Holding Company.</span>
              </div>
            </footer>
          </div>
        </Col>
      </Row>
    </div>
  );
};

export default Home;
