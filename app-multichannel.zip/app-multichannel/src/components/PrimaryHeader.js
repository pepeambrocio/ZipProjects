import React from "react";
import Navbar from "react-bootstrap/Navbar";
import Logo from "../components/EsiLogo";

function Header() {
  return (
    <div className="header d-flex">
      <Navbar
        className="bg-white justify-content-between w-100 border-bottom"
        fixed="top"
      >
        <Navbar.Brand href="/home">
          <Logo />
        </Navbar.Brand>
        <div className="d-flex text-muted m-lr-8"></div>
      </Navbar>
    </div>
  );
}

export default Header;
