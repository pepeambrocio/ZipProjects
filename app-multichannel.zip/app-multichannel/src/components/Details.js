import React from "react";
import { NavLink } from "react-router-dom";

const Details = (props) => {
  const { email, prescriptionNumber, birthDate } =
    (props.location && props.location.state) || {};
  return (
    <div>
      <NavLink to="/" activeClassName="active">
        Go Back
      </NavLink>
      <div className="form-details">
        <div>
          <strong>Email:</strong> {email}
        </div>
        <div>
          <strong>Prescription number:</strong> {prescriptionNumber}
        </div>
        <div>
          <strong>Birth date:</strong> {birthDate}
        </div>
      </div>
    </div>
  );
};

export default Details;
