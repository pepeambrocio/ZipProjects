import React from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Home from "./pages/Home";
import Details from "./components/Details";
import UserForm from "./pages/UserForm";
import PrimaryHeader from "./components/PrimaryHeader";

function App() {
  return (
    <BrowserRouter>
      <div className="container">
        <PrimaryHeader />
        <Switch>
          <Route component={Home} path="/" exact={true} />
          <Route component={UserForm} path="/userform" />
          <Route component={Details} path="/details" />
        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;
