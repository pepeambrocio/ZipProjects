﻿

namespace FlightJet.Persistence
{
    using System.Threading.Tasks;

    /// <summary>
    /// Interface IUnitOfWork
    /// the caller (service layer) will be responsible to send a Commit command to the database through a IUnitOfWork injected instance. 
    /// For this to be done will use a pattern called UnitOfWork
    /// Creation order: 5
    /// </summary>
    public interface IUnitOfWork
    {
        /// <summary>
        /// Begins transaction
        /// </summary>
        //void BeginTransaction();

        /// <summary>
        /// Commits transaction
        /// </summary>
        void Commit();

        /// <summary>
        /// Rollback transaction
        /// </summary>
        void Rollback();

        /// <summary>
        /// Saves changes into the persistence storage
        /// </summary>
        void SaveChanges();

        /// <summary>
        /// Saves changes into the persistence storage asynchronously
        /// </summary>
        /// <returns>A task that represents the asynchronous operation</returns>
        Task SaveChangesAsync();
    }
}
