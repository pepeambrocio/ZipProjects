﻿
namespace FlightJet.Persistence
{
    using FlightJet.Persistence.Facade;
    using Microsoft.EntityFrameworkCore;

    public class DbFactory : Disposable, IDbFactory
    {
        /// <summary>
        /// The database context
        /// </summary>
        private DomainModelFacade context;

        readonly DbContextOptions<DomainModelFacade> _options;

        /// <summary>
        /// Initializes this instance.
        /// </summary>
        /// <returns></returns>
        public DomainModelFacade Init()
        {            

            return context ?? (context = new DomainModelFacade(new DbContextOptions<DomainModelFacade>()));            
        }

        /// <summary>
        /// Override this to dispose custom objects
        /// </summary>
        protected override void DisposeCore()
        {
            if (context != null)
                context.Dispose();
        }
    }
}
