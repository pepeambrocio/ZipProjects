﻿
namespace FlightJet.Persistence
{
    using FlightJet.Persistence.Facade;
    using Microsoft.EntityFrameworkCore.Storage;
    using System;
    using System.Data;    
    using System.Threading.Tasks;

    /// <summary>
    /// Class UnitOfWork
    /// the caller (service layer) will be responsible to send a Commit command to the database through a IUnitOfWork injected instance.
    /// For this to be done will use a pattern called UnitOfWork
    /// Creation order: 6
    /// </summary>
    /// <seealso cref="System.IDisposable" />
    /// <seealso cref="VOI.ExchangeRatePersistence.Infraestructure.IUnitOfWork" />
    public class UnitOfWork : IUnitOfWork, IDisposable
    {
        private readonly IDbFactory dbFactory;
        private DomainModelFacade dbContext;
        private readonly IsolationLevel _isolationLevel;
        private IDbContextTransaction _transaction;

        public UnitOfWork(IDbFactory dbFactory)
        {
            this.dbFactory = dbFactory;
        }

        public DomainModelFacade DbContext
        {
            get { return dbContext ?? (dbContext = dbFactory.Init()); }
        }

        #region Interfaces Members

        /// <summary>
        /// Begins transaction
        /// </summary>
        //public void BeginTransaction()
        //{
        //    _transaction = DbContext.Database.BeginTransaction(_isolationLevel);
        //}

        /// <summary>
        /// Commits transaction
        /// </summary>
        public void Commit()
        {
            DbContext.Commit();
            CleanUpTransaction();
        }

        /// <summary>
        /// Rollback transaction
        /// </summary>
        public void Rollback()
        {
            _transaction?.Rollback();
            CleanUpTransaction();
        }

        /// <exception cref="DbUpdateException">An error occurred sending updates to the database.</exception>
        /// <exception cref="DbEntityValidationException">
        ///             The save was aborted because validation of entity property values failed.
        ///             </exception>
        /// <exception cref="DbUpdateConcurrencyException">
        ///             A database command did not affect the expected number of rows. This usually indicates an optimistic 
        ///             concurrency violation; that is, a row has been changed in the database since it was queried.
        ///             </exception>
        /// <exception cref="NotSupportedException">
        ///             An attempt was made to use unsupported behavior such as executing multiple asynchronous commands concurrently
        ///             on the same context instance.</exception>
        /// <exception cref="ObjectDisposedException">The context or connection have been disposed.</exception>
        /// <exception cref="InvalidOperationException">
        ///             Some error occurred attempting to process entities in the context either before or after sending commands
        ///             to the database.
        ///             </exception>
        public void SaveChanges()
        {
            DbContext.SaveChanges();
        }

        /// <exception cref="DbUpdateException">An error occurred sending updates to the database.</exception>
        /// <exception cref="DbUpdateConcurrencyException">
        ///             A database command did not affect the expected number of rows. This usually indicates an optimistic 
        ///             concurrency violation; that is, a row has been changed in the database since it was queried.
        ///             </exception>
        /// <exception cref="DbUpdateConcurrencyException">
        ///             A database command did not affect the expected number of rows. This usually indicates an optimistic 
        ///             concurrency violation; that is, a row has been changed in the database since it was queried.
        ///             </exception>
        /// <exception cref="DbUpdateConcurrencyException">
        ///             A database command did not affect the expected number of rows. This usually indicates an optimistic 
        ///             concurrency violation; that is, a row has been changed in the database since it was queried.
        ///             </exception>
        /// <exception cref="DbEntityValidationException">
        ///             The save was aborted because validation of entity property values failed.
        ///             </exception>
        /// <exception cref="NotSupportedException">
        ///             An attempt was made to use unsupported behavior such as executing multiple asynchronous commands concurrently
        ///             on the same context instance.</exception>
        /// <exception cref="ObjectDisposedException">The context or connection have been disposed.</exception>
        /// <exception cref="InvalidOperationException">
        ///             Some error occurred attempting to process entities in the context either before or after sending commands
        ///             to the database.
        ///             </exception>
        public Task SaveChangesAsync()
        {
            return DbContext.SaveChangesAsync();
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

        #region Private Members
        private void Dispose(Boolean disposing)
        {
            if (disposing)
            {
                _transaction?.Dispose();
                if(dbContext !=  null)
                    dbContext.Dispose();
            }
            // get rid of unmanaged resources
        }       

        private void CleanUpTransaction()
        {
            _transaction = null;
        }
        #endregion
    }
}
