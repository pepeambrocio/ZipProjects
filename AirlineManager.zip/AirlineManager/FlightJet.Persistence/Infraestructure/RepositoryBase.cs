﻿
namespace FlightJet.Persistence
{
    using FlightJet.Persistence.Facade;
    using Microsoft.EntityFrameworkCore;
    using System;
    using System.Collections.Generic;    
    using System.Linq;
    using System.Linq.Expressions;

    /// <summary>
    /// Abstract class RepositoryBase
    ///  This base class will be inherited from all specific repositories and hence 
    ///  will implement the IRepository interface
    /// Creation order: 7
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class RepositoryBase<T> where T : class
    {
        #region Properties
        private DomainModelFacade dataContext;
        private readonly DbSet<T> dbSet;

        /// <summary>
        /// Gets the database factory.
        /// </summary>
        /// <value>
        /// The database factory.
        /// </value>
        protected IDbFactory DbFactory
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets the database context.
        /// </summary>
        /// <value>
        /// The database context.
        /// </value>
        protected DomainModelFacade DbContext
        {
            get { return dataContext ?? (dataContext = DbFactory.Init()); }
        }
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="RepositoryBase{T}"/> class.
        /// </summary>
        /// <param name="dbFactory">The database factory.</param>
        protected RepositoryBase(IDbFactory dbFactory)
        {
            //Revisar 
            this.DbFactory = dbFactory;
            if (this.dbSet != null)
                this.dbSet = this.DbContext.Set<T>();
            else
                this.dbSet = this.DbContext.Set<T>();
        }

        #region Implementation
        /// <summary>
        /// Adds the specified entity.
        /// </summary>
        /// <param name="entity">The entity.</param>
        public virtual void Add(T entity)
        {
            dbSet.Add(entity);
        }

        /// <summary>
        /// Updates the specified entity.
        /// </summary>
        /// <param name="entity">The entity.</param>
        public virtual void Update(T entity)
        {
            dbSet.Attach(entity);
            dataContext.Entry(entity).State = EntityState.Modified;
        }

        /// <summary>
        /// Deletes the specified entity.
        /// </summary>
        /// <param name="entity">The entity.</param>
        public virtual void Delete(T entity)
        {
            dbSet.Remove(entity);
        }

        /// <summary>
        /// Deletes the specified where.
        /// </summary>
        /// <param name="where">The where.</param>
        public virtual void Delete(Expression<Func<T, bool>> where)
        {
            IEnumerable<T> objects = dbSet.Where<T>(where).AsEnumerable();
            foreach (T obj in objects)
                dbSet.Remove(obj);
        }

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public virtual T GetById(int id)
        {
            return dbSet.Find(id);
        }

        /// <summary>
        /// Gets all.
        /// </summary>
        /// <returns></returns>
        public virtual IEnumerable<T> GetAll()
        {
            return dbSet.ToList();
        }

        /// <summary>
        /// Gets the many.
        /// </summary>
        /// <param name="where">The where.</param>
        /// <returns></returns>
        public virtual IEnumerable<T> GetMany(Expression<Func<T, bool>> where)
        {
            return dbSet.Where(where).ToList();
        }

        /// <summary>
        /// Gets the specified where.
        /// </summary>
        /// <param name="where">The where.</param>
        /// <returns></returns>
        public T Get(Expression<Func<T, bool>> where)
        {
            return dbSet.Where(where).FirstOrDefault<T>();
        }

        public virtual DateTime GetServerDate()
        {
            //return this.DbContext.Database.SqlQuery<DateTime>("SELECT (GETDATE())").FirstOrDefault();
            return Convert.ToDateTime(DateTime.Now.Date);
        }
        #endregion

    }
}
