﻿
namespace FlightJet.Persistence
{
    using FlightJet.Persistence.Facade;
    using System;

    /// <summary>
    /// Interface IDbFactory 
    /// Factory Interface responsible to initialize instances of this class
    /// Creation order: 1    
    /// </summary>
    /// <seealso cref="System.IDisposable" />
    public interface IDbFactory : IDisposable
    {
        DomainModelFacade Init();
    }
}
