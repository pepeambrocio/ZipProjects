﻿



namespace FlightJet.Persistence.Mappings
{
    using FlightJet.Domain.Airport;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;

    public class AirportMap : IEntityTypeConfiguration<AirportEntity>
    {        
        public void Configure(EntityTypeBuilder<AirportEntity> builder)
        {
            builder.Property(e => e.StationCode)
                .IsUnicode(false)
                .HasColumnName("StationCode");

            builder.Property(e => e.StationName)
                .IsUnicode(false)
                .HasColumnName("StationName");

            builder.Property(e => e.CountryCode)
                .IsUnicode(false)
                .HasColumnName("CountryCode");

            builder.Property(e => e.AirportGroupCode)
                .IsUnicode(false)
                .HasColumnName("AirportGroupCode");

            builder.ToTable("Airport", "Airport");
        }
    }
}
