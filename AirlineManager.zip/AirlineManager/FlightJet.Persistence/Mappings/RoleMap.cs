﻿


namespace FlightJet.Persistence.Mappings
{
    using FlightJet.Domain.Security;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;

    public class RoleMap : IEntityTypeConfiguration<RoleEntity>
    {        
        public void Configure(EntityTypeBuilder<RoleEntity> builder)
        {
            builder.ToTable("Role", "Security");

            builder.Property(e => e.RoleCode)
                .IsUnicode(false)
                .HasColumnName("RoleCode");

            builder.Property(e => e.RoleName)
                .IsUnicode(false)
                .HasColumnName("RoleName");

            builder.HasMany(e => e.RoleModulePermissions);
        }
    }
}
