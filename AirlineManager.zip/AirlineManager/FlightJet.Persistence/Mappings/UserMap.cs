﻿

using FlightJet.Domain.Security;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FlightJet.Persistence.Mappings
{
    public class UserMap : IEntityTypeConfiguration<UserEntity>
    {        

        public void Configure(EntityTypeBuilder<UserEntity> builder)
        {
            builder.ToTable("Users", "Security");

            builder.HasKey(s => new { s.UserID});

            builder.Property(e => e.RoleCode)
                .IsUnicode(false)
                .HasColumnName("RoleCode");

            builder.Property(e => e.UserName)
                .IsUnicode(false)
                .HasColumnName("UserName");

            builder.Property(e => e.EmployeNo)
                .IsUnicode(false)
                .HasColumnName("EmployeNo");

            builder.Property(e => e.FirstName)
                .IsUnicode(false)
                .HasColumnName("FirstName");

            builder.Property(e => e.LastName)
                .IsUnicode(false)
                .HasColumnName("LastName");

            builder.Property(e => e.Email)
                .IsUnicode(false)
                .HasColumnName("Email");

            builder.Property(e => e.Password)
                .IsUnicode(false)
                .HasColumnName("Password");

        }
    }
}
