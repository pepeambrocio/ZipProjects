﻿

namespace FlightJet.Persistence.Mappings
{
    using FlightJet.Domain.Security;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;

    public class PermissionMap : IEntityTypeConfiguration<PermissionEntity>
    {        
        public void Configure(EntityTypeBuilder<PermissionEntity> builder)
        {
            builder.ToTable("Permission", "Security");

            builder.Property(e => e.PermissionCode)
                .IsUnicode(false)
                .HasColumnName("PermissionCode");

            builder.Property(e => e.PermissionName)
                .IsUnicode(false)                
                .HasColumnName("PermissionName");

            builder.HasMany(e => e.RoleModulePermissions);
        }
    }
}
