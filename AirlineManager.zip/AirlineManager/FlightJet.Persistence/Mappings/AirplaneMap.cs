﻿

namespace FlightJet.Persistence.Mappings
{
    using FlightJet.Domain.Airport;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class AirplaneMap : IEntityTypeConfiguration<AirplaneEntity>
    {
        public void Configure(EntityTypeBuilder<AirplaneEntity> builder)
        {
            builder.Property(e => e.EquipmentNumber)
                .IsUnicode(false)
                .HasColumnName("EquipmentNumber");

            builder.Property(e => e.AirlineCode)
                .IsUnicode(false)
                .HasColumnName("AirlineCode");

            builder.Property(e => e.AirplaneModel)
                .IsUnicode(false)
                .HasColumnName("AirplaneModel");

            builder.Property(e => e.MaximumTakeoffWeight)
                .HasColumnName("MaximumTakeoffWeight");

            builder.Property(e => e.WeightInPound)
                .HasColumnName("WeightInPound");

            builder.Property(e => e.WeightInTonnes)
                .HasColumnName("WeightInTonnes");

            builder.Property(e => e.SerialNumber)
                .IsUnicode(false)
                .HasColumnName("SerialNumber"); 

            builder.Property(e => e.EmptyOperatingWeight)
                .HasColumnName("EmptyOperatingWeight");

            builder.Property(e => e.FilmingMaximumWeight)
                .HasColumnName("FilmingMaximumWeight");

            builder.Property(e => e.TakeoffWeightInTonnes)
                .HasColumnName("TakeoffWeightInTonnes");

            builder.Property(e => e.GroupWeight)
                .HasColumnName("GroupWeight");

            builder.Property(e => e.MaximumLandingWeight)
                .HasColumnName("MaximumLandingWeight");

            builder.Property(e => e.MaximumZeroFuelWeight)
                .HasColumnName("MaximumZeroFuelWeight");

            builder.Property(e => e.Magnitude)
                .HasColumnName("Magnitude");

            builder.ToTable("Airplane", "Airport");
        }
    }
}
