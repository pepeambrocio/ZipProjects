﻿

namespace FlightJet.Persistence.Mappings
{
    using FlightJet.Domain.Catalog;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;

    public class CountryMap : IEntityTypeConfiguration<CountryEntity>
    {        
        public void Configure(EntityTypeBuilder<CountryEntity> builder)
        {
            // Define table´s name and name schema
            builder.ToTable("Country", "Catalog");

            builder.Property(e => e.CountryCode)
                .IsUnicode(false)
                .HasColumnName("CountryCode");

            builder.Property(e => e.CountryCodeShort)
                .IsUnicode(false)
                .HasColumnName("CountryCodeShort");

            builder.Property(e => e.CountryName)
                .IsUnicode(false)
                .HasColumnName("CountryName");

            builder.HasMany(e => e.Airports);
        }
    }
}
