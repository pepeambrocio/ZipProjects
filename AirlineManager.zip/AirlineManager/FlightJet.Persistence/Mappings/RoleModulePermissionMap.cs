﻿

using FlightJet.Domain.Security;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FlightJet.Persistence.Mappings
{
    public class RoleModulePermissionMap : IEntityTypeConfiguration<RoleModulePermissionEntity>
    {        
        public void Configure(EntityTypeBuilder<RoleModulePermissionEntity> builder)
        {
            builder.ToTable("RoleModulePermission", "Security");

            builder.HasKey(c => new { c.RoleCode, c.ModuleCode, c.PermissionCode});

            builder.Property(e => e.RoleCode)
                .IsUnicode(false)
                .HasColumnName("RoleCode");

            builder.Property(e => e.ModuleCode)
                .IsUnicode(false)
                .HasColumnName("ModuleCode");

            builder.Property(e => e.PermissionCode)
                .IsUnicode(false)
                .HasColumnName("PermissionCode");
        }
    }
}
