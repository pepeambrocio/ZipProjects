﻿
namespace FlightJet.Persistence.Mappings
{
    using FlightJet.Domain.Itinerary;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;

    public class ItineraryMap : IEntityTypeConfiguration<ItineraryEntity>
    {        
        public void Configure(EntityTypeBuilder<ItineraryEntity> builder)
        {
            builder.ToTable("Itinerary", "Itinerary");

            builder.HasKey(c => new {c.AirlineCode, c.FlightNumber, c.ItineraryKey});
            builder.Property(e => e.AirlineCode)
                .IsUnicode(false)
                .HasColumnName("AirlineCode");

            builder.Property(e => e.FlightNumber)
                .IsUnicode(false)
                .HasColumnName("FlightNumber");

            builder.Property(e => e.ItineraryKey)
                .IsUnicode(false)
                .HasColumnName("ItineraryKey");

            builder.Property(e => e.EquipmentNumber)
                .IsUnicode(false)
                .HasColumnName("EquipmentNumber");

            builder.Property(e => e.DepartureStation)
                .IsUnicode(false)
                .HasColumnName("DepartureStation");

            builder.Property(e => e.ArrivalStation)
                .IsUnicode(false)
                .HasColumnName("ArrivalStation");
        }
    }
}
