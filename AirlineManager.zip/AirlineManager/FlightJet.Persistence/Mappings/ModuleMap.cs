﻿


namespace FlightJet.Persistence.Mappings
{
    using FlightJet.Domain.Security;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;

    public class ModuleMap : IEntityTypeConfiguration<ModuleEntity>
    {        
        public void Configure(EntityTypeBuilder<ModuleEntity> builder)
        {
            // Define table´s name and name schema
            builder.ToTable("Module", "Security");

            builder.Property(e => e.ModuleCode)
               .IsUnicode(false)
               .HasColumnName("ModuleCode");

            builder.Property(e => e.ModuleName)
                .IsUnicode(false)
                .HasColumnName("ModuleName");

            builder.Property(e => e.MenuCode)
                .IsUnicode(false)
                .HasColumnName("MenuCode");

            builder.Property(e => e.ControllerName)
                .IsUnicode(false)
                .HasColumnName("ControllerName");

            builder.HasMany(e => e.RoleModulePermissions);
        }
    }
}
