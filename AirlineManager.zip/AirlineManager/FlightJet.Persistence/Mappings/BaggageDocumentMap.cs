﻿

namespace FlightJet.Persistence.Mappings
{
    using FlightJet.Domain.Airport;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;

    public class BaggageDocumentMap : IEntityTypeConfiguration<BaggageDocumentEntity>
    {        
        public void Configure(EntityTypeBuilder<BaggageDocumentEntity> builder)
        {
            // Define table´s name and name schema
            builder.ToTable("BaggageDocument", "Airport");

            builder.HasKey(c => new { c.PassengerID, c.AirlineCode, c.FlightNumber, c.ItineraryKey });
            builder.Property(e => e.AirlineCode)
                .IsUnicode(false)
                .HasColumnName("AirlineCode");

            builder.Property(e => e.FlightNumber)
                .IsUnicode(false)
                .HasColumnName("FlightNumber");

            builder.Property(e => e.ItineraryKey)
                .IsUnicode(false)
                .HasColumnName("ItineraryKey");

            builder.Property(e => e.FirstName)
                .IsUnicode(false)
                .HasColumnName("FirstName");

            builder.Property(e => e.LastName)
                .IsUnicode(false)
                .HasColumnName("LastName");
        }
    }
}
