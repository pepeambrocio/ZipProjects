﻿


namespace FlightJet.Persistence.Repositories.Itinerary
{

    using FlightJet.Domain.Common;
    using FlightJet.Domain.Itinerary;
    using FlightJet.Domain.Paged.Itinerary;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public interface IItineraryRepository : IRepository<ItineraryEntity>
    {
        PagedResult<ItineraryEntity> GetPagedResult(int page, int pageSize);
        ItineraryEntity FindItinerary(string equipmentNumber, DateTime departureDate,
            string departureStation);

        //int GetSequenceItinerary(string itineraryDte);

        ItineraryEntity FindItinerarybyId(string equipmentNumber, DateTime departureDate,
            string departureStation, string itineraryKey, string flightNumber);

        PagedResult<ItineraryEntity> GetDataPaginated(string filter, int initialPage, int pageSize);

        int GetSequenceItinerarybyDay();

    }
}
