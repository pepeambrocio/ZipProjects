﻿



namespace FlightJet.Persistence.Repositories.Itinerary
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;
    using FlightJet.Domain.Common;
    using FlightJet.Domain.Itinerary;
    using FlightJet.Domain.Paged.Itinerary;

    public class ItineraryRepository : RepositoryBase<ItineraryEntity>, IItineraryRepository
    {

        public ItineraryRepository(IDbFactory dbFactory) 
            : base(dbFactory)
        {
        }

        public ItineraryEntity FindItinerary(string equipmentNumber, DateTime departureDate, string departureStation)
        {            
            var itinerary = this.DbContext.Itineraries.Where(s => s.EquipmentNumber == equipmentNumber &&
            s.DepartureDate == departureDate && s.DepartureStation == departureStation &&
            s.Status == true).FirstOrDefault();

            return itinerary;
        }

        public ItineraryEntity FindItinerarybyId(string equipmentNumber, DateTime departureDate, 
            string departureStation, string itineraryKey, string flightNumber)
        {
            var itinerary = this.DbContext.Itineraries.Where(s => s.EquipmentNumber == equipmentNumber &&
           s.DepartureDate == departureDate && s.DepartureStation == departureStation &&
           s.ItineraryKey == itineraryKey && s.FlightNumber == flightNumber).FirstOrDefault();

            return itinerary;
        }

        public PagedResult<ItineraryEntity> GetDataPaginated(string filter, int initialPage, int pageSize)
        {
            int currentPage = initialPage;
            int currentPageSize = pageSize;
            var totalGet = this.DbContext.Itineraries.Where(s => s.DepartureDate.Date == DateTime.Now.Date
                            && s.Status == true).Count();

            var totalPages = (int)Math.Ceiling((double)totalGet / pageSize);

            IEnumerable<ItineraryEntity> customerList = this.DbContext.Itineraries
                .Where(s => s.DepartureDate.Date == DateTime.Now.Date && s.Status == true)
                .OrderBy(o => o.DepartureDate)
                .Skip((currentPage - 1) * currentPageSize)
                .Take(currentPageSize)
                .ToList();

            return new PagedResult<ItineraryEntity>
            {
                Results = customerList.ToList(),
                CurrentPage = currentPage,
                PageSize = pageSize,
                PageCount = totalPages,
                RowCount = totalGet
            };
        }

        public PagedResult<ItineraryEntity> GetPagedResult(int page, int pageSize)
        {
            int currentPage = page;
            int currentPageSize = pageSize;
            var totalGet = this.DbContext.Itineraries.Where(s=>s.DepartureDate.Date == DateTime.Now.Date
                             && s.Status == true).Count();            
            var totalPages = (int)Math.Ceiling((double)totalGet / pageSize);
            if (totalPages > 0)
            {
                IEnumerable<ItineraryEntity> customerList = this.DbContext.Itineraries
                    .Where(s => s.DepartureDate.Date == DateTime.Now.Date && s.Status == true)
                    .OrderBy(o => o.DepartureDate)
                    .Skip((currentPage - 1) * currentPageSize)
                    .Take(currentPageSize)
                    .ToList();

                return new PagedResult<ItineraryEntity>
                {
                    Results = customerList.ToList(),
                    CurrentPage = currentPage,
                    PageSize = pageSize,
                    PageCount = totalPages,
                    RowCount = totalGet
                };
            }
            else {
                return new PagedResult < ItineraryEntity >
                {
                    Results = new List<ItineraryEntity>(),
                    CurrentPage = currentPage,
                    PageSize = pageSize,
                    PageCount = totalPages,
                    RowCount = totalGet
                };
            }
        }

        public int GetSequenceItinerarybyDay()
        {
            Task<int> item = this.DbContext.GetSequenceItinerary(DateTime.Now.ToString("yyyyMMdd"));
            return item.Result;
        }

        IList<ItineraryEntity> IRepository<ItineraryEntity>.GetAll()
        {
            throw new System.NotImplementedException();
        }        
    }
}
