﻿

namespace FlightJet.Persistence.Repositories.Airport
{
    using FlightJet.Domain.Airport;
    using System;
    using System.Collections.Generic;
    using System.Text;

    public interface IAirplaneRepository : IRepository<AirplaneEntity>
    {
        /// <summary>
        /// Finds by the entity's identifier.
        /// </summary>
        /// <param name="id">The entity's identifier.</param>
        /// <returns>Airport Entity.</returns>
        AirplaneEntity FindById(string id);

        /// <summary>
        /// Gets the actives Airports.
        /// </summary>
        /// <returns>Airports marked as Actives.</returns>
        IList<AirplaneEntity> GetActivesAirplanes();
    }
}
