﻿

namespace FlightJet.Persistence.Repositories.Airport
{
    using FlightJet.Domain.Airport;
    using Microsoft.EntityFrameworkCore;
    using System;
    using System.Collections.Generic;    
    using System.Linq;

    public class AirportRepository : RepositoryBase<AirportEntity>, IAirportRepository
    {
        public AirportRepository(IDbFactory dbFactory) : base(dbFactory)
        {
        }

        public AirportEntity FindById(string id)
        {
            var airports = this.DbContext.Airports
               .Where(c => c.StationCode == id)
               .Include(c => c.Country)
               .FirstOrDefault();

            return airports;
        }

        public IList<AirportEntity> GetActivesAirports()
        {
            return this.DbContext.Airports.Where(c => c.Status == true).ToList();
        }

        public IList<string> ValidatedIfAirportExist(IList<string> stationCodes)
        {
            IList<string> notFound = new List<string>();
            IList<AirportEntity> airportList = this.DbContext.Airports.Where(c => c.Status).ToList();

            notFound = stationCodes.Except(airportList.Select(c => c.StationCode)).ToList();
            return notFound;
        }

        IList<AirportEntity> IRepository<AirportEntity>.GetAll()
        {
            return this.DbContext.Airports.Where(c => c.Status == true).OrderBy(n=>n.StationCode).ToList();
        }
    }
}
