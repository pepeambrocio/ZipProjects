﻿
namespace FlightJet.Persistence.Repositories.Airport
{
    using FlightJet.Domain.Airport;
    using FlightJet.Domain.Common;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;


    public class BaggageDocumentRepository : RepositoryBase<BaggageDocumentEntity>, IBaggageDocumentRepository
    {
        public BaggageDocumentRepository(IDbFactory dbFactory) 
            : base(dbFactory)
        {
        }

        public BaggageDocumentEntity FindBaggageDocument(int passengerID, string airlineCode, string flightNumber, string itineraryKey)
        {
            var baggageDocument = this.DbContext.BaggageDocuments.Where(s => s.PassengerID == passengerID &&
                                s.AirlineCode == airlineCode && s.FlightNumber == flightNumber &&
                                s.FlightNumber == flightNumber).FirstOrDefault();

            return baggageDocument;
        }

        public PagedResult<BaggageDocumentEntity> GetDataPaginated(string filter, int initialPage, int pageSize,
            string airlineCode, string flightNumber, string itineraryKey)
        {
            int currentPage = initialPage;
            int currentPageSize = pageSize;
            var totalGet = this.DbContext.BaggageDocuments.Where(s => s.AirlineCode == airlineCode && s.FlightNumber == flightNumber &&
                                s.FlightNumber == flightNumber).Count();

            var totalPages = (int)Math.Ceiling((double)totalGet / pageSize);

            IEnumerable<BaggageDocumentEntity> customerList = this.DbContext.BaggageDocuments
                .Where(s => s.AirlineCode == airlineCode && s.FlightNumber == flightNumber &&
                                s.FlightNumber == flightNumber)
                .OrderBy(o => o.PassengerID)
                .Skip((currentPage - 1) * currentPageSize)
                .Take(currentPageSize)
                .ToList();

            return new PagedResult<BaggageDocumentEntity>
            {
                Results = customerList.ToList(),
                CurrentPage = currentPage,
                PageSize = pageSize,
                PageCount = totalPages,
                RowCount = totalGet
            };
        }

        public PagedResult<BaggageDocumentEntity> GetPagedResult(int page, int pageSize,
             string airlineCode, string flightNumber, string itineraryKey)
        {
            int currentPage = page;
            int currentPageSize = pageSize;
            var totalGet = this.DbContext.BaggageDocuments.Where(s => s.AirlineCode == airlineCode && s.FlightNumber == flightNumber &&
                                s.FlightNumber == flightNumber).Count();
            var totalPages = (int)Math.Ceiling((double)totalGet / pageSize);
            if (totalPages > 0)
            {
                IEnumerable<BaggageDocumentEntity> customerList = this.DbContext.BaggageDocuments
                    .Where(s => s.AirlineCode == airlineCode && s.FlightNumber == flightNumber &&
                                s.FlightNumber == flightNumber)
                    .OrderBy(o => o.PassengerID)
                    .Skip((currentPage - 1) * currentPageSize)
                    .Take(currentPageSize)
                    .ToList();

                return new PagedResult<BaggageDocumentEntity>
                {
                    Results = customerList.ToList(),
                    CurrentPage = currentPage,
                    PageSize = pageSize,
                    PageCount = totalPages,
                    RowCount = totalGet
                };
            }
            else
            {
                return new PagedResult<BaggageDocumentEntity>
                {
                    Results = new List<BaggageDocumentEntity>(),
                    CurrentPage = currentPage,
                    PageSize = pageSize,
                    PageCount = totalPages,
                    RowCount = totalGet
                };
            }
        }

        public int GetSequenceBaggageDocument(string airlineCode, string flightNumber, string itineraryKey)
        {
            var Secuence = this.DbContext.BaggageDocuments.Where(s => s.AirlineCode == airlineCode && s.FlightNumber == flightNumber &&
                                s.FlightNumber == flightNumber).Select( s=> s.PassengerID).DefaultIfEmpty(0).Max();

            return Secuence;
        }

        IList<BaggageDocumentEntity> IRepository<BaggageDocumentEntity>.GetAll()
        {
            throw new NotImplementedException();
        }
    }
}
