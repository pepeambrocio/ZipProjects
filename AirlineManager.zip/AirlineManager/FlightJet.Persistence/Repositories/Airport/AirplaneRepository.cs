﻿

namespace FlightJet.Persistence.Repositories.Airport
{
    using FlightJet.Domain.Airport;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class AirplaneRepository : RepositoryBase<AirplaneEntity>, IAirplaneRepository
    {
        public AirplaneRepository(IDbFactory dbFactory) : base(dbFactory)
        {
        }

        public AirplaneEntity FindById(string id)
        {
            throw new NotImplementedException();
        }

        public IList<AirplaneEntity> GetActivesAirplanes()
        {
            return this.DbContext.Airplanes.Where(s => s.Status == true).OrderBy(o => o.EquipmentNumber).ToList();
        }

        IList<AirplaneEntity> IRepository<AirplaneEntity>.GetAll()
        {
            return this.DbContext.Airplanes.Where(s => s.Status == true).OrderBy(o => o.EquipmentNumber).ToList();
        }
    }
}
