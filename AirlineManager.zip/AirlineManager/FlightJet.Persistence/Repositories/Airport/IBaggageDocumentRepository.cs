﻿
namespace FlightJet.Persistence.Repositories.Airport
{
    using FlightJet.Domain.Airport;
    using FlightJet.Domain.Common;
    using System;
    using System.Collections.Generic;
    using System.Text;


    public interface IBaggageDocumentRepository : IRepository<BaggageDocumentEntity>
    {
        PagedResult<BaggageDocumentEntity> GetPagedResult(int page, int pageSize,
            string airlineCode, string flightNumber, string itineraryKey);

        BaggageDocumentEntity FindBaggageDocument(int passengerID, string airlineCode,
            string flightNumber, string itineraryKey);

        PagedResult<BaggageDocumentEntity> GetDataPaginated(string filter, int initialPage, int pageSize,
            string airlineCode, string flightNumber, string itineraryKey);

        int GetSequenceBaggageDocument(string airlineCode,
            string flightNumber, string itineraryKey);
    }
}
