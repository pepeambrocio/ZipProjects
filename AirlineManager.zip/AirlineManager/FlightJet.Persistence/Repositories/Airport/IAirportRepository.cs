﻿
namespace FlightJet.Persistence.Repositories.Airport
{
    using FlightJet.Domain.Airport;
    using System;
    using System.Collections.Generic;

    public interface IAirportRepository : IRepository<AirportEntity>
    {
        /// <summary>
        /// Finds by the entity's identifier.
        /// </summary>
        /// <param name="id">The entity's identifier.</param>
        /// <returns>Airport Entity.</returns>
        AirportEntity FindById(string id);

        /// <summary>
        /// Gets the actives Airports.
        /// </summary>
        /// <returns>Airports marked as Actives.</returns>
        IList<AirportEntity> GetActivesAirports();

        /// <summary>
        /// Validate if the airports exist.
        /// </summary>
        /// <param name="stationCodes">The station codes to validate.</param>
        /// <returns>Returns a list with the Station Codes that do not exist, if all of them exist returns NULL.</returns>
        IList<string> ValidatedIfAirportExist(IList<string> stationCodes);
    }
}
