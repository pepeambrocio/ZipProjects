﻿

namespace FlightJet.Persistence.Repositories.Catalog
{
    using FlightJet.Domain.Catalog;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="FlightJet.Persistence.RepositoryBase{FlightJet.Domain.Catalog.CountryEntity}" />
    /// <seealso cref="FlightJet.Persistence.Repositories.Catalog.ICountryRepository" />
    public class CountryRepository : RepositoryBase<CountryEntity>, ICountryRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CountryRepository"/> class.
        /// </summary>
        /// <param name="dbFactory">The database factory.</param>
        public CountryRepository(IDbFactory dbFactory) : base(dbFactory)
        {
        }

        public CountryEntity FindById(string id)
        {
            var country = this.DbContext.Countries.Where(c => c.CountryCode == id).FirstOrDefault();
            return country;
        }

        public ICollection<CountryEntity> GetActiveCountry()
        {
            return this.DbContext.Countries.Where(s=>s.Status == true).OrderBy(s=>s.CountryName).ToList();
        }

        IList<CountryEntity> IRepository<CountryEntity>.GetAll()
        {
            return this.DbContext.Countries.OrderBy(s=>s.CountryName).ToList();
        }
    }
}
