﻿

namespace FlightJet.Persistence.Repositories.Catalog
{
    using FlightJet.Domain.Catalog;
    using System;
    using System.Collections.Generic;

    public interface ICountryRepository : IRepository<CountryEntity>
    {
        ICollection<CountryEntity> GetActiveCountry();

        CountryEntity FindById(string id);

    }
}
