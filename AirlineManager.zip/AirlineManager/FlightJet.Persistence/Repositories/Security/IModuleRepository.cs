﻿
namespace FlightJet.Persistence.Repositories.Security
{
    using FlightJet.Domain.Common;
    using FlightJet.Domain.Security;
    using System.Collections.Generic;

    public interface IModuleRepository : IRepository<ModuleEntity>
    {
        /// <summary>
        /// Finds by the entity's identifier.
        /// </summary>
        /// <param name="id">The entity's identifier.</param>
        /// <returns>FuelConcept Entity.</returns>
        UserEntity FindById(long id);

        /// <summary>
        /// FindByControllerName
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        UserEntity FindByControllerName(string controllerName);

        /// <summary>
        /// FindByType
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        List<UserEntity> FindByType(ModuleType moduleType);
    }
}
