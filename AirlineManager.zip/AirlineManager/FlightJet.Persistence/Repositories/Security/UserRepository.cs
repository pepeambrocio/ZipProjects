﻿

namespace FlightJet.Persistence.Repositories.Security
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;    
    using FlightJet.Domain.Security;
    using FlightJet.Domain.Common;
    using Microsoft.EntityFrameworkCore;


    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="ForeignTrade.Data.Infraestructure.RepositoryBase{ForeignTrade.Entities.Security.User}" />
    /// <seealso cref="ForeignTrade.Data.Repository.Security.IUserRepository" />
    public class UserRepository : RepositoryBase<UserEntity>, IUserRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UserRepository"/> class.
        /// </summary>
        /// <param name="factory">The factory.</param>
        public UserRepository(IDbFactory factory)
            : base(factory)
        {
        }

        public UserEntity FindById(long id)
        {
            var user = this.DbContext.Users.Where(c => c.UserID == id && c.Status == 1)
                .Include(p => p.Role)
                .FirstOrDefault();

            return user;
        }

        public UserEntity FindByUserName(string userName)
        {
            var user = this.DbContext.Users.Where(c => c.UserName == userName && c.Status == 1)
                .Include(p => p.Role)
                .Include(p => p.Role.RoleModulePermissions)
                .Include("Role.RoleModulePermissions.Module")
                .Include("Role.RoleModulePermissions.Permission")
                //.Include(p => p.UserModules.Select(u => u.Module))
                .FirstOrDefault();

            return user;
        }

        public UserEntity FindByUserNameEdit(string userName, long userId)
        {
            throw new NotImplementedException();
        }

        public IList<UserEntity> GetActivesUsers()
        {
            List<UserEntity> users = new List<UserEntity>();
            users = this.DbContext.Users.Where(c => c.Status == 1).ToList<UserEntity>();

            return users;
        }

        public new IList<UserEntity> GetAll()
        {
            List<UserEntity> users = new List<UserEntity>();
            users = this.DbContext.Users.Where(c => c.Status == 1).ToList<UserEntity>();

            return users;
        }

        public PagedResult<UserEntity> GetPagedUsers(FilterGrid filter)
        {

            string search = filter.Search != null && !string.IsNullOrEmpty(filter.Search) ? filter.Search : string.Empty;

            var usersFilter = this.DbContext.Users
                .AsQueryable()
                .Where(u => u.Status == 1 && u.UserName.Contains(search))
                .OrderBy(o => o.UserID)
                .Skip((filter.Offset / filter.Limit) * filter.Limit)
                .Take(filter.Limit)
                .ToList();

            return new PagedResult<UserEntity>
            {
                Results = usersFilter.ToList(),
                CurrentPage = 0,
                PageSize = 0,
                PageCount = 0,
                RowCount = this.DbContext.Users.Where(u => u.Status == 1 && u.UserName.Contains(search)).Count()
            };
        }
    }
}
