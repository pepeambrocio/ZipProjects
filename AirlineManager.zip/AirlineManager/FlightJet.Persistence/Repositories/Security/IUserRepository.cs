﻿

namespace FlightJet.Persistence.Repositories.Security
{
    using FlightJet.Domain.Common;
    using FlightJet.Domain.Security;
    using System;
    using System.Collections.Generic;

    public interface IUserRepository : IRepository<UserEntity>
    {
        /// <summary>
        /// Finds by the entity's identifier.
        /// </summary>
        /// <param name="id">The entity's identifier.</param>
        /// <returns>FuelConcept Entity.</returns>
        UserEntity FindById(long id);

        /// <summary>
        /// FindByUserName
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        UserEntity FindByUserName(string userName);

        /// <summary>
        /// FindByUserNameEdit
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        UserEntity FindByUserNameEdit(string userName, long userId);

        /// <summary>
        /// Gets the Actives FuelConcepts.
        /// </summary>
        /// <returns>FuelConcepts marked as Actives.</returns>
        IList<UserEntity> GetActivesUsers();

        PagedResult<UserEntity> GetPagedUsers(FilterGrid filter);
    }
}
