﻿

namespace FlightJet.Persistence.Repositories.Security
{
    using FlightJet.Domain.Security;

    public interface IRoleRepository : IRepository<RoleEntity>
    {

    }
}
