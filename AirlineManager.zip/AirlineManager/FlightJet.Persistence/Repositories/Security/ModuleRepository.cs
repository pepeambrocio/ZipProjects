﻿

namespace FlightJet.Persistence.Repositories.Security
{
    using FlightJet.Domain.Common;
    using FlightJet.Domain.Security;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="ForeignTrade.Data.Infraestructure.RepositoryBase{ForeignTrade.Entities.Security.Module}"/>
    /// <seealso cref="ForeignTrade.Data.Repository.Security.IModuleRepository"/>
    public class ModuleRepository : RepositoryBase<ModuleEntity>, IModuleRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UserRepository"/> class.
        /// </summary>
        /// <param name="factory">The factory.</param>
        public ModuleRepository(IDbFactory factory)
            : base(factory)
        {
        }

        public UserEntity FindById(long id)
        {
            throw new NotImplementedException();
        }

        public UserEntity FindByControllerName(string controllerName)
        {
            throw new NotImplementedException();
        }

        public List<UserEntity> FindByType(ModuleType moduleType)
        {
            throw new NotImplementedException();
        }

        public new IList<ModuleEntity> GetAll()
        {
            throw new NotImplementedException();
        }
    }
}
