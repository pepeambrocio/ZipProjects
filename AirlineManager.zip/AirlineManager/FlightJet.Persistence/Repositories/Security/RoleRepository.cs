﻿

namespace FlightJet.Persistence.Repositories.Security
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using FlightJet.Domain.Security;

    public class RoleRepository : RepositoryBase<RoleEntity>, IRoleRepository
    {
        public RoleRepository(IDbFactory factory)
            : base(factory)
        {
        }
        IList<RoleEntity> IRepository<RoleEntity>.GetAll()
        {
            return this.DbContext.Roles.ToList();
        }
    }
}
