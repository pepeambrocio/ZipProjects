﻿


namespace FlightJet.Persistence.Facade
{
    using FlightJet.Domain.Airport;
    using FlightJet.Domain.Catalog;
    using FlightJet.Domain.Itinerary;
    using FlightJet.Domain.Security;
    using FlightJet.Persistence.Mappings;
    using Microsoft.EntityFrameworkCore;
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Threading.Tasks;

    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="System.Data.Entity.DbContext" />
    public class DomainModelFacade : DbContext
    {
        
        public DomainModelFacade(DbContextOptions<DomainModelFacade> options)
            :  base(options)
        {
            //options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"));
        }

        /// <summary>
        /// Commits this instance.
        /// </summary>
        public virtual void Commit()
        {
            base.SaveChanges();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"data source=LENOVO-PC;initial catalog=AIRLINEMANAGER;user id=sa;password=desa;MultipleActiveResultSets=True;App=EntityFramework;");
            //optionsBuilder.UseSqlServer(@"data source=trainingsession.database.windows.net;initial catalog=AIRLINEMANAGER;user id=jose.ambrocio;password=Developer5;MultipleActiveResultSets=True;App=EntityFramework;");
        }

        /// <summary>
        /// This method is called when the model for a derived context has been initialized, but
        /// before the model has been locked down and used to initialize the context.  The default
        /// implementation of this method does nothing, but it can be overridden in a derived class
        /// such that the model can be further configured before it is locked down.
        /// </summary>
        /// <param name="modelBuilder">The builder that defines the model for the context being created.</param>
        /// <remarks>
        /// Typically, this method is called only once when the first instance of a derived context
        /// is created.  The model for that context is then cached and is for all further instances of
        /// the context in the app domain.  This caching can be disabled by setting the ModelCaching
        /// property on the given ModelBuidler, but note that this can seriously degrade performance.
        /// More control over caching is provided through use of the DbModelBuilder and DbContextFactory
        /// classes directly.
        /// </remarks>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            /*
             * El choro de arriba se resume en que en esta parte se agregan las configuraciones iniciales
             * de Entity Framework. Para nuestro acercamiento de CodeFirst se estan creando configuraciones
             * específicas para cada entidad y en esta sección se deben de registrar.
             */            
            modelBuilder.ApplyConfiguration(new AirportMap());
            modelBuilder.ApplyConfiguration(new AirplaneMap());
            modelBuilder.ApplyConfiguration(new BaggageDocumentMap());
            modelBuilder.ApplyConfiguration(new CountryMap());
            modelBuilder.ApplyConfiguration(new ItineraryMap());

            modelBuilder.ApplyConfiguration(new ModuleMap());
            modelBuilder.ApplyConfiguration(new PermissionMap());
            modelBuilder.ApplyConfiguration(new RoleMap());
            modelBuilder.ApplyConfiguration(new RoleModulePermissionMap());
            modelBuilder.ApplyConfiguration(new UserMap());
        }

        #region Tables Airport
        public virtual DbSet<AirportEntity> Airports { get; set; }
        public virtual DbSet<AirplaneEntity> Airplanes { get; set; }
        public virtual DbSet<BaggageDocumentEntity> BaggageDocuments { get; set; }                
        #endregion

        #region Tables Catalog
        public virtual DbSet<CountryEntity> Countries { get; set; }
        #endregion

        #region Tables Itinerary
        public virtual DbSet<ItineraryEntity> Itineraries { get; set; }
        #endregion

        #region Tables Security
        public virtual DbSet<ModuleEntity> Modules { get; set; }
        public virtual DbSet<PermissionEntity> Permissions { get; set; }
        public virtual DbSet<RoleEntity> Roles { get; set; }
        public virtual DbSet<RoleModulePermissionEntity> RoleModulePermissions { get; set; }
        public virtual DbSet<UserEntity> Users { get; set; }
        #endregion

        #region Store Procedures
        public virtual async Task<int> GetSequenceItinerary(string ItineraryDte)
        {
            int result = 0;
            object[] sqlParams = new object[0];

            try
            {
                var SequenceParameter = new SqlParameter("ItineraryDte", ItineraryDte);

                sqlParams = new object[]{
                    SequenceParameter
                };
                using (var command = this.Database.GetDbConnection().CreateCommand())
                {
                    command.CommandText = "[Itinerary].[uspGetSequenceItinerary]";
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.Add(new SqlParameter("@ItineraryDte", SqlDbType.VarChar) { Value = ItineraryDte });
                    command.Parameters.Add(new SqlParameter("@Id", SqlDbType.Int) { Direction = ParameterDirection.Output });

                    if (command.Connection.State != ConnectionState.Open)
                    {
                        command.Connection.Open();
                    }

                    await command.ExecuteNonQueryAsync();

                    result = (int)command.Parameters["@Id"].Value;
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            finally {

            }

            return result;
        }
        #endregion
    }
}
