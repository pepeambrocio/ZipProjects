﻿



namespace FlightJet.Domain.Common
{
    using System.ComponentModel;

    public class Reference
    {
    }

    /// <summary>
    /// 
    /// </summary>
    public enum ModuleType
    {
        [Description("CATALOGS")]
        CATALOGS = 0,

        [Description("AIRPORT")]
        AIRPORT = 1,

        [Description("SECURITY")]
        SECURITY = 2,

        [Description("ITINERNARY")]
        ITINERNARY = 3,
    }

    [System.Runtime.Serialization.DataContractAttribute(Name = "ResponseStatus")]
    public enum ResponseStatus
    {
        [System.Runtime.Serialization.EnumMemberAttribute()]
        OK = 0,

        [System.Runtime.Serialization.EnumMemberAttribute()]
        ERROR = -1
    }
}
