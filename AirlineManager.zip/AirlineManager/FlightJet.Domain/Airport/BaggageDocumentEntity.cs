﻿

namespace FlightJet.Domain.Airport
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public partial class BaggageDocumentEntity
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int PassengerID { get; set; }        

        [Key]
        [Column(Order = 1)]
        [StringLength(3)]
        public string AirlineCode { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(5)]
        public string FlightNumber { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(8)]
        public string ItineraryKey { get; set; }

        [Required]
        [StringLength(100)]
        public string FirstName { get; set; }

        [Required]
        [StringLength(100)]
        public string LastName { get; set; }

        public int Piece { get; set; }

        public decimal? Weight { get; set; }
    }
}
