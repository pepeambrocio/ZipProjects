﻿

namespace FlightJet.Domain.Airport
{
    using FlightJet.Domain.Catalog;
    using System;
    using System.ComponentModel.DataAnnotations;

    public partial class AirportEntity
    {
        [Key]
        [StringLength(3)]
        public string StationCode { get; set; }

        [Required]
        [StringLength(100)]
        public string StationName { get; set; }

        [Required]
        [StringLength(3)]
        public string CountryCode { get; set; }

        public TimeSpan? OpeningTime { get; set; }

        public TimeSpan? ClosingTime { get; set; }

        [StringLength(8)]
        public string AirportGroupCode { get; set; }

        public bool Status { get; set; }

        public virtual CountryEntity Country { get; set; }
    }
}
