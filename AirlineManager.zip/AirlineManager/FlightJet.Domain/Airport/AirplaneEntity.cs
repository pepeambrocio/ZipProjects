﻿

namespace FlightJet.Domain.Airport
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Text;
    public class AirplaneEntity
    {
        [Key]
        [StringLength(12)]
        public string EquipmentNumber { get; set; }

        [Required]
        [StringLength(3)]
        public string AirlineCode { get; set; }

        [Required]
        [StringLength(12)]
        public string AirplaneModel { get; set; }

        [Column(TypeName = "numeric")]
        public decimal MaximumTakeoffWeight { get; set; }

        [Column(TypeName = "numeric")]
        public decimal WeightInPound { get; set; }

        [Column(TypeName = "numeric")]
        public decimal WeightInTonnes { get; set; }

        [StringLength(20)]
        public string SerialNumber { get; set; }

        [Column(TypeName = "numeric")]
        public decimal EmptyOperatingWeight { get; set; }

        [Column(TypeName = "numeric")]
        public decimal FilmingMaximumWeight { get; set; }

        [Column(TypeName = "numeric")]
        public decimal TakeoffWeightInTonnes { get; set; }

        [Column(TypeName = "numeric")]
        public decimal GroupWeight { get; set; }

        [Column(TypeName = "numeric")]
        public decimal MaximumLandingWeight { get; set; }

        [Column(TypeName = "numeric")]
        public decimal MaximumZeroFuelWeight { get; set; }

        public int PassengerCapacity { get; set; }

        public int CrewCapacity { get; set; }

        [Column(TypeName = "numeric")]
        public decimal Magnitude { get; set; }

        public bool Status { get; set; }
    }
}
