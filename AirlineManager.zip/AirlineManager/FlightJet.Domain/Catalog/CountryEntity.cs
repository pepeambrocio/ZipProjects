﻿



namespace FlightJet.Domain.Catalog
{
    using FlightJet.Domain.Airport;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public partial class CountryEntity
    {        
        public CountryEntity()
        {
            Airports = new HashSet<AirportEntity>();
        }

        [Key]
        [StringLength(3)]
        public string CountryCode { get; set; }

        [Required]
        [StringLength(2)]
        public string CountryCodeShort { get; set; }

        [Required]
        [StringLength(50)]
        public string CountryName { get; set; }

        public bool Status { get; set; }
        
        public virtual ICollection<AirportEntity> Airports { get; set; }
    }
}
