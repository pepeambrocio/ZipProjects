﻿

namespace FlightJet.Domain.Itinerary
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public partial class ItineraryEntity
    {        
        [Key]
        [Column(Order = 0)]
        [StringLength(3)]
        public string AirlineCode { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(5)]
        public string FlightNumber { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(8)]
        public string ItineraryKey { get; set; }

        [Required]
        [StringLength(12)]
        public string EquipmentNumber { get; set; }

        public DateTime DepartureDate { get; set; }

        [Required]
        [StringLength(3)]
        public string DepartureStation { get; set; }

        public DateTime ArrivalDate { get; set; }

        [Required]
        [StringLength(3)]
        public string ArrivalStation { get; set; }

        public bool Status { get; set; }
    }
}
