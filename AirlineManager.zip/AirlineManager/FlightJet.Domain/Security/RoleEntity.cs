﻿
namespace FlightJet.Domain.Security
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    public partial class RoleEntity
    {
        public RoleEntity()
        {
            RoleModulePermissions = new HashSet<RoleModulePermissionEntity>();
            Users = new HashSet<UserEntity>();
        }

        [Key]
        [StringLength(10)]
        public string RoleCode { get; set; }

        [Required]
        [StringLength(50)]
        public string RoleName { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<RoleModulePermissionEntity> RoleModulePermissions { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<UserEntity> Users { get; set; }
    }
}