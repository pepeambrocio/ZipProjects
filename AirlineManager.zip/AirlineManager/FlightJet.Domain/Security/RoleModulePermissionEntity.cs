﻿
namespace FlightJet.Domain.Security
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public partial class RoleModulePermissionEntity
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(10)]
        public string RoleCode { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(10)]
        public string ModuleCode { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(10)]
        public string PermissionCode { get; set; }

        public virtual ModuleEntity Module { get; set; }

        public virtual PermissionEntity Permission { get; set; }

        public virtual RoleEntity Role { get; set; }
    }
}