﻿
namespace FlightJet.Domain.Security
{
    using System;
    using System.ComponentModel.DataAnnotations;
    public partial class UserEntity
    {
        public long UserID { get; set; }

        [StringLength(10)]
        public string RoleCode { get; set; }

        [StringLength(50)]
        public string UserName { get; set; }

        [StringLength(50)]
        public string EmployeNo { get; set; }

        [StringLength(80)]
        public string FirstName { get; set; }

        [StringLength(100)]
        public string LastName { get; set; }

        [StringLength(250)]
        public string Email { get; set; }

        public bool? UserDomain { get; set; }

        public string Password { get; set; }

        public int IsAdmin { get; set; }

        public DateTime Init { get; set; }

        public int Status { get; set; }

        public virtual RoleEntity Role { get; set; }
    }
}
