﻿

namespace FlightJet.Domain.Security
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public partial class ModuleEntity
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public ModuleEntity()
        {
            RoleModulePermissions = new HashSet<RoleModulePermissionEntity>();
        }

        [Key]
        [StringLength(10)]
        public string ModuleCode { get; set; }

        [Required]
        [StringLength(150)]
        public string ModuleName { get; set; }

        [Required]
        [StringLength(5)]
        public string MenuCode { get; set; }

        [StringLength(150)]
        public string ControllerName { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<RoleModulePermissionEntity> RoleModulePermissions { get; set; }
    }
}