﻿

namespace FlightJet.Domain.Security
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public partial class PermissionEntity
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public PermissionEntity()
        {
            RoleModulePermissions = new HashSet<RoleModulePermissionEntity>();
        }

        [Key]
        [StringLength(10)]
        public string PermissionCode { get; set; }

        [StringLength(50)]
        public string PermissionName { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<RoleModulePermissionEntity> RoleModulePermissions { get; set; }
    }
}