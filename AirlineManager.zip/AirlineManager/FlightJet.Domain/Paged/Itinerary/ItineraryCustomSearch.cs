﻿

namespace FlightJet.Domain.Paged.Itinerary
{
    using System;
    public class ItineraryCustomSearch
    {
        public string EquipmentNumber { get; set; }

        public DateTime DepartureDate { get; set; }

        public string DepartureStation { get; set; }        

        public string ArrivalStation { get; set; }
    }
}
