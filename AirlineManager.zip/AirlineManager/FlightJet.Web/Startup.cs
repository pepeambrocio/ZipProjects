﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Autofac;
using Autofac.Extensions.DependencyInjection;
using Autofac.Multitenant;
using FlightJet.Application.Configuration;
using FlightJet.Persistence.Facade;
using FlightJet.Web.Config;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace FlightJet.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }        

        // This method gets called by the runtime. Use this method to add services to the container.
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();

            //Culture
            services.Configure<RequestLocalizationOptions>(options =>
            {
                options.DefaultRequestCulture = new RequestCulture("es-MX");
            });

            //EF
            services.AddEntityFrameworkSqlServer();
            var optionss = new DbContextOptionsBuilder<DomainModelFacade>().UseSqlServer(Configuration.GetConnectionString("DBConnectionString")).Options;


            services.AddDbContext<DomainModelFacade>(options =>
                    options.UseSqlServer(Configuration.GetConnectionString("DBConnectionString")));
            
            //services.AddDbContext<DomainModelFacade>(o =>
            //      o.UseSqlServer(Configuration
            //      ["DBConnectionString"]));

            //Authenticate
            services.AddAuthentication("AirLineSecurityCookie")
                .AddCookie("AirLineSecurityCookie", options => {
                    options.LoginPath = "/Account/Index/";
                });

            // configure strongly typed settings objects
            var appSettingsSection = Configuration.GetSection("AppSettings");
            services.Configure<AppSettings>(appSettingsSection);

            //services.AddIdentity<ApplicationUser, IdentityRole>()
            //    .AddEntityFrameworkStores<DomainModelFacade>()
            //    .AddDefaultTokenProviders();

            //AutoFac
            var builder = new ContainerBuilder();
            builder.RegisterModule(new AutofacModuleConfig());            
            builder.Populate(services);            
            var container = builder.Build();
            return new AutofacServiceProvider(container);


        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseBrowserLink();
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();

            app.UseAuthentication();

            app.UseRequestLocalization();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                     name: "areaRoute",
                     template: "{area:exists}/{controller=Home}/{action=Index}/{id?}");

                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
