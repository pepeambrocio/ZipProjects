﻿
var BaggageDocumentJS = {
    tableBaggage: null,
    airlineCode: null,
    flightNumber: null,
    itineraryKey: null,
    iniciar: function () {
        
    },
    InitializeForm: function (itinerary) {
        //BaggageDocumentJS.dataTableInit();
        $("#departureDateDayInfo").html(moment(itinerary.departureDate).format('DD'));
        $("#departureDateMonthInfo").html(moment(itinerary.departureDate).format('MMMM'));
        $("#equipmentNumberInfo").html('<i class="plane icon"></i>' + itinerary.equipmentNumber);
        $("#DepartureArrivalInfo").html(itinerary.departureStation + '-' + itinerary.arrivalStation);

        BaggageDocumentJS.airlineCode = itinerary.airlineCode;
        BaggageDocumentJS.flightNumber = itinerary.flightNumber;
        BaggageDocumentJS.itineraryKey = itinerary.itineraryKey;
    },
    dataTableInit: function () {
        
    },
    printBaggageDoc: function () {
        alert('Hola');
    },
    validateNumericInput: function (charInput) {
        var rx = /^\d+(?:\.\d{1,2})?$/;
        if (rx.test(charInput)) {
            return true;
        } else {
            return false;
        }
    },
    savePassengerBaggage: function (baggagePiece, baggageWeight) {

        var passengerBaggageJson = {            
            AirlineCode: BaggageDocumentJS.airlineCode,
            FlightNumber: BaggageDocumentJS.flightNumber,
            ItineraryKey: BaggageDocumentJS.itineraryKey,
            Piece: baggagePiece,
            Weight: baggageWeight
        };

        $.ajax({
            url: '/Itinerary/Itinerary/AddPassengerBaggageDoc',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(passengerBaggageJson),
            success: function (result) {
                if (result.responseStatus === 0) {
                    $('#addBaggageModal')
                        .modal('hide');
                    reloadFormPassengerDocForm();

                    alertify.success('Se agrego el nuevo itinerario!.');                    
                }
                else {
                    alertify.error(result.message);
                }
                console.log(result);
            }
        });
    }


};

$(document).ready(BaggageDocumentJS.iniciar);