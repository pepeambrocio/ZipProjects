﻿var PassengerDocumentJS = {
    iniciar: function () {
    },
    passengerDocumentInitial: function (itinerary) {
        $(itinerary.equipmentNumber).appendTo('#equipmentNumberInfo');
        $(moment(itinerary.departureDate).format('DD')).appendTo('#departureDateDayInfo');


    }
};

$(document).ready(PassengerDocumentJS.iniciar);