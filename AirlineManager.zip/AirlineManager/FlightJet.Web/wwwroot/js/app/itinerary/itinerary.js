﻿var ItineraryJs = {    
    iniciar: function () {
        $("#itineraryForm")
            .form({
                fields: {
                    departureDate: {
                        identifier: 'departureDate',
                        rules: [
                            {
                                type: 'empty',
                                prompt: 'Indique la fecha de salida.'
                            }
                        ]
                    },
                    departureDateHr: {
                        identifier: 'departureDateHr',
                        rules: [
                            {
                                type: 'empty',
                                prompt: 'Indique la hora de salida.'
                            }
                        ]
                    },
                    arraivalDate: {
                        identifier: 'arraivalDate',
                        rules: [
                            {
                                type: 'empty',
                                prompt: 'Indique la fecha de arribo.'
                            }
                        ]
                    },
                    arraivalDateHr: {
                        identifier: 'arraivalDateHr',
                        rules: [
                            {
                                type: 'empty',
                                prompt: 'Indique la hora de arribo.'
                            }
                        ]
                    },
                    DLDepartureAiport: {
                        identifier: 'DLDepartureAiport',
                        rules: [
                            {
                                type: 'empty',
                                prompt: 'Seleccione el aeropuerto de despegue.'
                            }
                        ]
                    },
                    DLArraivalAiport: {
                        identifier: 'DLArraivalAiport',
                        rules: [
                            {
                                type: 'empty',
                                prompt: 'Seleccione el aeropuerto de arribo.'
                            }
                        ]
                    },
                    DLAiplane: {
                        identifier: 'DLAiplane',
                        rules: [
                            {
                                type: 'empty',
                                prompt: 'Seleccione la aeronave.'
                            }
                        ]
                    }
                }
            });

        var check_in = flatpickr("#departureDate", {
            minDate: new Date(),
            dateFormat: "Y-m-d"
        });

        var check_out = flatpickr("#arraivalDate", {
            minDate: new Date(),
            dateFormat: "Y-m-d"
        });

        check_in.element.addEventListener("change", function () {
            check_out.set("minDate", check_in.element.value);
        });

        check_out.element.addEventListener("change", function () {
            check_in.set("maxDate", check_out.element.value);
        });
        
        flatpickr('#departureDateHr', {
            enableTime: true,
            noCalendar: true,
            dateFormat: "H:i",
        });
       
        flatpickr('#arraivalDateHr', {
            enableTime: true,
            noCalendar: true,
            dateFormat: "H:i",
        });

        //Initial cbo
        ItineraryJs.getAirports();
        ItineraryJs.getAirplanes();     
       
    },
    getAirports: function () {
        $.get("/Itinerary/Itinerary/GetAirports", function (data, textStatus, jqXHR) {
            //alert(data);            
            if (data.responseStatus === 0) {
                var listItems = '<option selected="selected" value="0">- Select -</option>';
                for (var i = 0; i < data.genericList.length; i++) {
                    listItems += "<option value='" + data.genericList[i].stationCode + "'>" + data.genericList[i].stationCode + "</option>";
                }

                $("#DLDepartureAiport").html(listItems);
                $("#DLArraivalAiport").html(listItems);
            }
        });
    },
    getAirplanes: function () {
        $.get("/Itinerary/Itinerary/GetAirplanes", function (data, textStatus, jqXHR) {
            //alert(data);
            //var airportJSON = JSON.stringify(data);
            if (data.responseStatus === 0) {
                var $select = $('#DLAiplane');

                var listItems = '<option selected="selected" value="0">- Select -</option>';
                //clear the current content of the select
                $select.html('');

                //iterate over the data and append a select option
                $.each(data.genericList, function (key, val) {
                    $select.append('<option id="' + val.equipmentNumber + '">' + val.equipmentNumber + '</option>');
                })              
            }
        });
    },

    addInitialItinerary: function () {
        //var form1;
        //form1 = form1 || $('#itineraryForm').show()[0];
        //alertify.customModal(form1).set('title', 'Editar Itinerario');

                  
    },
    addItinerary: function () {
        var departureDate = $('#departureDate').val() + ' ' + $('#departureDateHr').val();
        var arraivalDate = $('#arraivalDate').val() + ' ' + $('#arraivalDateHr').val();

        if ($('#departureDate').val().length === 0 || $('#departureDateHr').val().length === 0) 
            alertify.error('Indique la fecha/Hora de salida.');        
        else if ($('#arraivalDate').val().length === 0 || $('#departureDateHr').val().length === 0) 
            alertify.error('Indique la fecha/Hora de llegada.');
        else if ($("#DLDepartureAiport").val() === "0")
            alertify.error('Seleccione el aeropuerto de salida.');
        else if ($("#DLArraivalAiport").val() === "0")
            alertify.error('Seleccione el aeropuerto de llegada.');
        else if ($("#DLDepartureAiport").val() === $("#DLArraivalAiport").val())
            alertify.error('No puede seleccinar el mismo aeropuerto de Origen/Destino.');
        else if (!moment(departureDate, 'YYYY-MM-DD HH:mm:ss').isValid()) 
            alertify.error('Fecha de salida no valida');
        else if (!moment(arraivalDate, 'YYYY-MM-DD HH:mm:ss').isValid())
            alertify.error('Fecha de llegada no valida');
        else {
            var ItineraryJson = {
                Sequence : '1',
                AirlineCode : 'ALE',
                FlightNumber : '1',
                ItineraryKey : '',
                EquipmentNumber : $("#DLAiplane").val(),
                DepartureDate : departureDate,
                DepartureStation : $("#DLDepartureAiport").val(),
                ArrivalDate : arraivalDate,
                ArrivalStation : $("#DLArraivalAiport").val()
            };

            $.ajax({
                url: '/Itinerary/Itinerary/AddItinerary',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(ItineraryJson),
                success: function (result) {
                    if (result.responseStatus === 0) {
                        //var form1;
                        //form1 = form1 || $('#itineraryForm').show()[0];
                        //alertify.customModal(form1).close();         
                        $('#itineraryForm')
                            .modal('hide');
                        reloadDataTable();
                        

                        alertify.success('Se agrego el nuevo Itinerario.');                        
                        //reloadFormPassengerDocForm();
                    }
                    else {
                        alertify.error(result.message);
                    }
                    console.log(result);
                }
            });
        }
    },
    editInitialItinerary: function (itineraryEdit) {
        //var form1;
        //form1 = form1 || $('#itineraryForm').show()[0];
        //alertify.customModal(form1).set('title', 'Editar Itinerario');
        $('#itineraryForm')
            .modal({
                inverted: true,
                allowMultiple: true
            })
            .modal('show');

        $('#departureDate').val(moment(itineraryEdit.departureDate).format('YYYY-MM-DD'));
        $('#departureDateHr').val(moment(itineraryEdit.departureDate).format('HH:mm'))
        $('#arraivalDate').val(moment(itineraryEdit.arrivalDate).format('YYYY-MM-DD'));
        $('#arraivalDateHr').val(moment(itineraryEdit.arrivalDate).format('HH:mm'));
        $("#DLDepartureAiport").val(itineraryEdit.departureStation);
        $("#DLArraivalAiport").val(itineraryEdit.arrivalStation);
        $("#DLAiplane").val(itineraryEdit.equipmentNumber);
        $("#_AirlineCode").val(itineraryEdit.airlineCode);
        $("#_FlightNumber").val(itineraryEdit.flightNumber);
        $("#_ItineraryKey").val(itineraryEdit.itineraryKey);

        
        $('#departureDate').prop('disabled', true);
        $('#departureDateHr').prop('disabled', true);        

        $('#arraivalDate').prop('disabled', true);        
        $('#arraivalDateHr').prop('disabled', true);                    

        $('#DLDepartureAiport').addClass("disabled");
        $('#DLArraivalAiport').addClass("disabled");

        $('#updateItinerary').show();
        $('#addItinerary').hide();        
    },

    updateItinerary: function () {
        var departureDate = $('#departureDate').val() + ' ' + $('#departureDateHr').val();
        var arraivalDate = $('#arraivalDate').val() + ' ' + $('#arraivalDateHr').val();

        var ItineraryJsonUpdate = {
            Sequence: '1',
            AirlineCode: $("#_AirlineCode").val(),
            FlightNumber: $("#_FlightNumber").val(),
            ItineraryKey: $("#_ItineraryKey").val(),
            EquipmentNumber: $("#DLAiplane").val(),
            DepartureDate: departureDate,
            DepartureStation: $("#DLDepartureAiport").val(),
            ArrivalDate: arraivalDate,
            ArrivalStation: $("#DLArraivalAiport").val()
        };

        $.ajax({
            url: '/Itinerary/Itinerary/UpdateItinerary',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(ItineraryJsonUpdate),
            success: function (result) {
                if (result.responseStatus === 0) {
                    //var form1;
                    //form1 = form1 || $('#itineraryForm').show()[0];
                    //alertify.customModal(form1).close();

                    $('#itineraryForm')
                        .modal('hide');

                    alertify.success('Se actualizó el itinerario!.');
                    reloadDataTable();
                }
                else {
                    alertify.error(result.message);
                }
                console.log(result);
            }
        });
    }    


};

$(document).ready(ItineraryJs.iniciar);