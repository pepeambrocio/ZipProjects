﻿
namespace FlightJet.Web.Models.Response
{
    using FlightJet.Domain.Common;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Threading.Tasks;

    public class ResponseListGeneric<T>  where T : class 
    {
        private ResponseStatus StatusField;

        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Raises the property changed.
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        protected void RaisePropertyChanged(string propertyName)
        {
            System.ComponentModel.PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
            if ((propertyChanged != null))
            {
                propertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
            }
        }

        public ResponseStatus ResponseStatus
        {
            get
            {
                return this.StatusField;
            }
            set
            {
                if ((this.StatusField.Equals(value) != true))
                {
                    this.StatusField = value;
                    this.RaisePropertyChanged("ResponseStatus");
                }
            }
        }
        public string Message { get; set; }
        public List<T> GenericList { get; set; }
    }
}
