﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FlightJet.Application.Airport;
using FlightJet.Application.DTO.Airport;
using FlightJet.Application.DTO.Itinerary;
using FlightJet.Application.Itinerary;
using FlightJet.Web.Areas.Itinerary.Models;
using FlightJet.Web.Models.Response;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FlightJet.Web.Areas.Itinerary.Controllers
{
    [Authorize]
    [Area("Itinerary")]

    public class ItineraryController : Controller
    {
        /// <summary>
        /// The logger
        /// </summary>
        private static readonly log4net.ILog Logger = log4net.LogManager.GetLogger(typeof(ItineraryController));

        private readonly IItineraryApplication itineraryApplication;
        private readonly IAirportApplication airportApplication;
        private readonly IAirplaneApplication airplaneApplication;
        private readonly IBaggageDocumentApplication baggageDocumentApplication;

        public ItineraryController(IItineraryApplication itineraryApplication,
            IAirportApplication airportApplication,
            IAirplaneApplication airplaneApplication,
            IBaggageDocumentApplication baggageDocumentApplication)
        {
            this.itineraryApplication = itineraryApplication ?? throw new ArgumentNullException(nameof(itineraryApplication));
            this.airportApplication = airportApplication ?? throw new ArgumentNullException(nameof(airportApplication));
            this.airplaneApplication = airplaneApplication ?? throw new ArgumentNullException(nameof(airplaneApplication));
            this.baggageDocumentApplication = baggageDocumentApplication ?? throw new ArgumentNullException(nameof(baggageDocumentApplication));
        }

        public IActionResult Index(Int32? page, Int32? rows)
        {
            //var customerPaged = this.itineraryApplication.GetPagedResult(page ?? 1, rows ?? 3);
            return View();
        }
        
        public IActionResult GetItineraryPaged(Int32? draw, Int32? start, Int32? length)
        {

            //var totalRecords = 0;
            //var recordsFiltered = 0;
            start = start.HasValue ? start/5 : 0;
           
            var customerPaged = this.itineraryApplication.ItineraryCustomSearchFunc("", start.Value > 0 ? start.Value : 1, length ?? 5);
            return Json(new { draw = draw ?? 1, recordsTotal = customerPaged.RowCount,
                recordsFiltered = customerPaged.RowCount,  data = customerPaged.Results });

            //return View(customerPaged);
        }

        public IActionResult PassengerDocument()
        {
            //var customerPaged = this.itineraryApplication.GetPagedResult(page ?? 1, rows ?? 3);
            return View();
        }

        [HttpPost]
        public IActionResult AddItinerary([FromBody] ItineraryDTO itinerary)
        {
            ResponseGeneric response = new ResponseGeneric();

            try
            {
                if (itinerary.EquipmentNumber != null && itinerary.DepartureDate != null &&
                itinerary.DepartureStation != null && itinerary.ArrivalDate != null &&
                itinerary.ArrivalStation != null)
                {

                    var itineraryResponse = itineraryApplication.AddItinerary(itinerary);
                    response.ResponseStatus = Domain.Common.ResponseStatus.OK;
                    response.Message = "Con éxito";
                }
                else {
                    response.ResponseStatus = Domain.Common.ResponseStatus.ERROR;
                    response.Message = "Complete la información requerida, Error al guardar.";
                }
            }
            catch (Exception ex)
            {

                response.ResponseStatus = Domain.Common.ResponseStatus.ERROR;
                response.Message = $@"Error al guardar, MessageErr({ex.Message})";
            }
            
            
            return Json(response);
        }

        [HttpPost]
        public IActionResult UpdateItinerary([FromBody]ItineraryDTO itinerary)
        {
            ResponseGeneric response = new ResponseGeneric();

            try
            {
                if (itinerary.EquipmentNumber != null && itinerary.DepartureDate != null &&
                itinerary.DepartureStation != null && itinerary.ArrivalDate != null &&
                itinerary.ArrivalStation != null)
                {

                    var itineraryResponse = itineraryApplication.UpdateItinerary(itinerary);
                    response.ResponseStatus = Domain.Common.ResponseStatus.OK;
                    response.Message = "Con éxito";
                }
                else
                {
                    response.ResponseStatus = Domain.Common.ResponseStatus.ERROR;
                    response.Message = "Complete la información requerida, Error al guardar.";
                }
            }
            catch (Exception ex)
            {

                response.ResponseStatus = Domain.Common.ResponseStatus.ERROR;
                response.Message = $@"Error al guardar, MessageErr({ex.Message})";
            }


            return Json(response);
        }

        public JsonResult GetAirports()
        {
            ResponseListGeneric<AirportDTO> generic = new ResponseListGeneric<AirportDTO>();

            try
            {
                
                var airports = airportApplication.GetAllAirport();
                generic.ResponseStatus = Domain.Common.ResponseStatus.OK;
                generic.GenericList = airports.ToList();                
            }
            catch (Exception ex)
            {
                generic.ResponseStatus = Domain.Common.ResponseStatus.ERROR;
                generic.Message = $@"Error to get airports, MessageErr({ex.Message})";
            }

            return Json(generic);

        }

        public JsonResult GetAirplanes()
        {
            ResponseListGeneric<AirplaneDTO> generic = new ResponseListGeneric<AirplaneDTO>();

            try
            {

                var airports = airplaneApplication.GetActivesAirplanes();
                generic.ResponseStatus = Domain.Common.ResponseStatus.OK;
                generic.GenericList = airports.ToList();
            }
            catch (Exception ex)
            {
                generic.ResponseStatus = Domain.Common.ResponseStatus.ERROR;
                generic.Message = $@"Error to get airplanes, MessageErr({ex.Message})";
            }

            return Json(generic);

        }

        #region BaggageDocument
        [HttpPost]
        public IActionResult GetBaggageDocumentPaged(DTParamItineraryVO dTParam)//(object input, Int32? draw, Int32? start, Int32? length, string airlineCode, string flightNumber, string itineraryKey)
        {

            //var totalRecords = 0;
            //var recordsFiltered = 0;
            dTParam.start = dTParam.start.HasValue ? dTParam.start / 5 : 0;

            if (!string.IsNullOrEmpty(dTParam.itineraryKey))
            {
                var customerPaged = this.baggageDocumentApplication
                .ItineraryCustomSearchFunc("", dTParam.start.Value > 0 ? dTParam.start.Value : 1, dTParam.length ?? 5,
                    dTParam.airlineCode, dTParam.flightNumber, dTParam.itineraryKey);
                return Json(new
                {
                    draw = dTParam.draw ?? 1,
                    recordsTotal = customerPaged.RowCount,
                    recordsFiltered = customerPaged.RowCount,
                    data = customerPaged.Results
                });
            }
            else
            {
                return Json(new
                {
                    draw = 0,
                    recordsTotal = 0,
                    recordsFiltered = 0,
                    data = new  List<BaggageDocumentDTO>()
                });
            }
            

            //return View(customerPaged);
        }

        [HttpPost]
        public IActionResult AddPassengerBaggageDoc([FromBody] PassengerBaggageDocumentVO doc)
        {
            ResponseGeneric response = new ResponseGeneric();

            try
            {
                if (!string.IsNullOrEmpty(doc.AirlineCode) &&
                    !string.IsNullOrEmpty(doc.FlightNumber) &&
                    !string.IsNullOrEmpty(doc.ItineraryKey))                
                {

                    var itineraryResponse = baggageDocumentApplication
                        .AddBaggageDocument(new BaggageDocumentDTO {                            
                            AirlineCode = doc.AirlineCode,
                            FlightNumber = doc.FlightNumber,
                            ItineraryKey = doc.ItineraryKey,
                            Piece = doc.Piece,
                            Weight = doc.Weight
                        });
                    response.ResponseStatus = Domain.Common.ResponseStatus.OK;
                    response.Message = "Con éxito";
                }
                else
                {
                    response.ResponseStatus = Domain.Common.ResponseStatus.ERROR;
                    response.Message = "Complete la información requerida, Error al guardar.";
                }
            }
            catch (Exception ex)
            {

                response.ResponseStatus = Domain.Common.ResponseStatus.ERROR;
                response.Message = $@"Error al guardar, MessageErr({ex.Message})";
            }


            return Json(response);
        }
        #endregion

    }
}