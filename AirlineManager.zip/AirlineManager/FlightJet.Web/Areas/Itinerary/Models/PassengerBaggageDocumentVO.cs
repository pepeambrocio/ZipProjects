﻿
namespace FlightJet.Web.Areas.Itinerary.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;


    public class PassengerBaggageDocumentVO
    {
        public int PassengerID { get; set; }

        public int Sequence { get; set; }

        public string AirlineCode { get; set; }

        public string FlightNumber { get; set; }

        public string ItineraryKey { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public int Piece { get; set; }

        public decimal Weight { get; set; }
    }
}
