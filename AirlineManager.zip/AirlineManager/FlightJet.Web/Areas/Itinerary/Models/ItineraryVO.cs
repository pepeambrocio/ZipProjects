﻿

namespace FlightJet.Web.Areas.Itinerary.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class ItineraryVO
    {
        public int Sequence { get; set; }

        public string AirlineCode { get; set; }

        public string FlightNumber { get; set; }

        public string ItineraryKey { get; set; }

        public string EquipmentNumber { get; set; }

        public DateTime DepartureDate { get; set; }

        public string DepartureStation { get; set; }

        public DateTime ArrivalDate { get; set; }

        public string ArrivalStation { get; set; }
    }
}
