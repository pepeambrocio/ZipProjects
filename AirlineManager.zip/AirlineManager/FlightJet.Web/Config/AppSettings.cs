﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightJet.Web.Config
{
    public class AppSettings
    {
        public string Secret { get; set; }        
    }
}
