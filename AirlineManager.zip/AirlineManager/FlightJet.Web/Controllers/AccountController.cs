﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using FlightJet.Application.DTO.Security;
using FlightJet.Application.Security;
using FlightJet.Web.Models.Security;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace FlightJet.Web.Controllers
{
    public class AccountController : Controller
    {
        /// <summary>
        /// The logger
        /// </summary>
        private static readonly log4net.ILog Logger = log4net.LogManager.GetLogger(typeof(AccountController));

        private readonly IUserApplication userApplication;

        public AccountController(IUserApplication userApplication)
        {
            this.userApplication = userApplication ?? throw new ArgumentNullException(nameof(userApplication));
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult Index(string returnUrl = null)
        {
            var model = new LoginViewModel { ReturnUrl = returnUrl };
            return View(model);
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel loginModel, string returnUrl = null)
        {
            if (ModelState.IsValid)
            {

                var pass = loginModel.Password.ToArray();

                var personIdentity =
                userApplication.UserAuthenticate(new UserDTO
                {
                    UserName = loginModel.UserName,
                    Password = loginModel.Password.Trim()
                });

                if (personIdentity.UserID > 0)
                {
                    var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, loginModel.UserName)
                    };

                    var userIdentity = new ClaimsIdentity(claims, "cookie_AirLine");

                    ClaimsPrincipal principal = new ClaimsPrincipal(userIdentity);

                    await HttpContext.SignInAsync(
                            scheme: "AirLineSecurityCookie",
                            principal: principal);

                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError("", "Usuario/contraseña no valido.");
                }
            }
            return View("Index", loginModel);

        }

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        public async Task<IActionResult> LogOut()
        {
            await HttpContext.SignOutAsync();
            return RedirectToAction(nameof(HomeController.Index), "Home");
        }
    }
}