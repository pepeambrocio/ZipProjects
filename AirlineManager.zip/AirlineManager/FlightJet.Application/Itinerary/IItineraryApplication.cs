﻿


namespace FlightJet.Application.Itinerary
{
    using FlightJet.Application.DTO.Itinerary;
    using FlightJet.Domain.Common;
    using FlightJet.Domain.Paged;
    using FlightJet.Domain.Paged.Itinerary;
    using System;
    using System.Collections.Generic;

    public interface IItineraryApplication
    {


        /// <summary>
        /// Finds the itinerary by identifier.
        /// </summary>
        /// <param name="equipmentNumber">The equipment number.</param>
        /// <param name="departureDate">The departure date.</param>
        /// <param name="departureStation">The departure station.</param>
        /// <param name="itineraryKey">The itinerary key.</param>
        /// <returns></returns>
        ItineraryDTO FindItineraryById(ItineraryDTO entity);

        /// <summary>
        /// Adds the itinerary.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns>true or false</returns>
        bool AddItinerary(ItineraryDTO entity);

        /// <summary>
        /// Deletes the itinerary.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns>true or false</returns>
        bool DeleteItinerary(ItineraryDTO entity);

        /// <summary>
        /// Updates the itinerary.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns>true or false</returns>
        bool UpdateItinerary(ItineraryDTO entity);

        PagedResult<ItineraryDTO> GetPagedResult(int page, int pageSize);

        PagedResult<ItineraryDTO> ItineraryCustomSearchFunc(string filter, int initialPage, int pageSize);
    }
}
