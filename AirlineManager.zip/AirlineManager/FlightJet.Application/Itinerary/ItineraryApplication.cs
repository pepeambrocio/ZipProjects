﻿



namespace AirLine.Application.Itinerary
{
    using System;
    using System.Collections.Generic;
    using AutoMapper;
    using FlightJet.Application.DTO.Itinerary;
    using FlightJet.Application.Itinerary;
    using FlightJet.Domain.Common;
    using FlightJet.Domain.Itinerary;
    using FlightJet.Domain.Paged;
    using FlightJet.Domain.Paged.Itinerary;
    using FlightJet.Persistence;
    using FlightJet.Persistence.Repositories.Itinerary;

    public class ItineraryApplication : IItineraryApplication
    {
        /// <summary>
        /// The unit of work
        /// </summary>
        private readonly IUnitOfWork unitOfWork;

        /// <summary>
        /// The itinerary repository
        /// </summary>
        private readonly IItineraryRepository itineraryRepository;

        public ItineraryApplication(IUnitOfWork unitOfWork, IItineraryRepository itineraryRepository)
        {
            this.unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
            this.itineraryRepository = itineraryRepository ?? throw new ArgumentNullException(nameof(itineraryRepository));
        }

        public bool AddItinerary(ItineraryDTO entity)
        {
            ItineraryEntity itinerary = new ItineraryEntity();

            if (entity == null)
            {
                return false;
            }

            
            if (this.IsItineraryDuplicate(entity.EquipmentNumber, entity.DepartureDate, entity.DepartureStation))
            {
                throw new ApplicationException("Regristro duplicado");
            }

            try
            {                
                itinerary.AirlineCode = entity.AirlineCode;
                itinerary.FlightNumber = this.itineraryRepository.GetSequenceItinerarybyDay().ToString();
                itinerary.ItineraryKey = $"{DateTime.Now.ToString("yy")}{DateTime.Now.ToString("MM")}{DateTime.Now.ToString("dd")}";
                itinerary.EquipmentNumber = entity.EquipmentNumber;
                itinerary.DepartureDate = entity.DepartureDate;
                itinerary.DepartureStation = entity.DepartureStation;
                itinerary.ArrivalDate = entity.ArrivalDate;
                itinerary.ArrivalStation = entity.ArrivalStation;
                itinerary.Status = true;
                this.itineraryRepository.Add(itinerary);
                this.unitOfWork.Commit();

                return true;
            }
            catch (Exception exception)
            {
                throw new ApplicationException(exception.Message);
            }
        }

        public bool DeleteItinerary(ItineraryDTO entity)
        {
            try
            {
                ItineraryEntity itineraryEntity = this.itineraryRepository.FindItinerarybyId(entity.EquipmentNumber,
                    entity.DepartureDate, entity.DepartureStation, entity.ItineraryKey, entity.FlightNumber);

                if (itineraryEntity != null)
                {
                    /*
                    * Si se quiere hacer un borrado permanente de la DB
                    * se debe de usar la siguiente instrucción:
                    * this.countryRepository.Delete(country);
                    */

                    // Para borrado lógico
                    
                    this.itineraryRepository.Delete(itineraryEntity);
                    this.unitOfWork.Commit();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception exception)
            {
                throw new ApplicationException(exception.Message);
            }
        }

        public ItineraryDTO FindItineraryById(ItineraryDTO entity)
        {
            try
            {
                ItineraryEntity itineraryEntity = this.itineraryRepository.FindItinerarybyId(entity.EquipmentNumber,
                    entity.DepartureDate, entity.DepartureStation, entity.ItineraryKey, entity.FlightNumber);

                ItineraryDTO countryDto = new ItineraryDTO();
                countryDto = Mapper.Map<ItineraryEntity, ItineraryDTO>(itineraryEntity);

                return countryDto;
            }
            catch (Exception exception)
            {
                throw new ApplicationException(exception.Message);
            }
        }

        public bool UpdateItinerary(ItineraryDTO entity)
        {
            try
            {
                ItineraryEntity itineraryEntity = this.itineraryRepository.FindItinerarybyId(entity.EquipmentNumber,
                    entity.DepartureDate, entity.DepartureStation, entity.ItineraryKey, entity.FlightNumber);


                itineraryEntity.EquipmentNumber = entity.EquipmentNumber;
                itineraryEntity.DepartureStation = entity.DepartureStation;
                itineraryEntity.DepartureDate = entity.DepartureDate;
                itineraryEntity.ArrivalStation = entity.ArrivalStation;
                itineraryEntity.ArrivalDate = entity.ArrivalDate;

                this.itineraryRepository.Update(itineraryEntity);
                this.unitOfWork.Commit();
                return true;
            }
            catch (Exception exception)
            {
                throw new ApplicationException(exception.Message);
            }
        }

        public bool IsItineraryDuplicate(string equipmentNumber, DateTime departureDate, 
            string departureStation)
        {
            ItineraryEntity itinerary = this.itineraryRepository.FindItinerary(equipmentNumber, 
                                            departureDate, departureStation);
            return itinerary != null ? true : false;
        }

        public PagedResult<ItineraryDTO> GetPagedResult(int page, int pageSize)
        {
            try
            {
                var paged = itineraryRepository.GetPagedResult(page, pageSize);
                List<ItineraryDTO> lst = new List<ItineraryDTO>();

                foreach (var item in paged.Results)
                {
                    lst.Add(
                        new ItineraryDTO
                        {                            
                            AirlineCode = item.AirlineCode,
                            FlightNumber = item.FlightNumber,
                            ItineraryKey = item.ItineraryKey,
                            EquipmentNumber = item.EquipmentNumber,
                            DepartureDate = item.DepartureDate,
                            DepartureStation = item.DepartureStation,
                            ArrivalDate = item.ArrivalDate,
                            ArrivalStation = item.ArrivalStation
                            
                        });
                }
                return new PagedResult<ItineraryDTO>
                {
                    Results = lst,
                    CurrentPage = page,
                    PageSize = pageSize,
                    PageCount = paged.PageCount,
                    RowCount = paged.RowCount
                };
            }
            catch (Exception ex)
            {
                throw new ApplicationException($"Error to get Paged : {ex?.InnerException}");
            }
        }

        public PagedResult<ItineraryDTO> ItineraryCustomSearchFunc(string filter, int initialPage, int pageSize)
        {
            try
            {
                var paged = itineraryRepository.GetPagedResult(initialPage, pageSize);
                List<ItineraryDTO> lst = new List<ItineraryDTO>();

                foreach (var item in paged.Results)
                {
                    lst.Add(
                        new ItineraryDTO
                        {
                            AirlineCode = item.AirlineCode,
                            FlightNumber = item.FlightNumber,
                            ItineraryKey = item.ItineraryKey,
                            EquipmentNumber = item.EquipmentNumber,
                            DepartureDate = item.DepartureDate,
                            DepartureStation = item.DepartureStation,
                            ArrivalDate = item.ArrivalDate,
                            ArrivalStation = item.ArrivalStation

                        });
                }
                return new PagedResult<ItineraryDTO>
                {
                    Results = lst,
                    CurrentPage = paged.CurrentPage,
                    PageSize = pageSize,
                    PageCount = paged.PageCount,
                    RowCount = paged.RowCount
                };
            }
            catch (Exception ex)
            {
                throw new ApplicationException($"Error to get Paged : {ex?.InnerException}");
            }
        }
    }
}
