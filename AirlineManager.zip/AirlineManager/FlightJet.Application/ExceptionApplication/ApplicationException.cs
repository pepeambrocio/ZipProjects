﻿

namespace FlightJet.Application.ExceptionApplication
{
    using System;

    class ApplicationException : Exception
    {
        /// <summary>
        /// The code
        /// </summary>
        private string code;

        /// <summary>
        /// The message own
        /// </summary>
        private string messageOwn;

        /// <summary>
        /// The number
        /// </summary>
        private int number;

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceException"/> class.
        /// </summary>
        /// <param name="message">The message that describes the error.</param>
        public ApplicationException(string message) : base(message) { }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code.
        /// </value>
        public string Code
        {
            get { return this.code; }
            set { this.code = value; }
        }

        /// <summary>
        /// Gets or sets the message own.
        /// </summary>
        /// <value>
        /// The message own.
        /// </value>
        public string MessageOwn
        {
            get { return this.messageOwn; }
            set { this.messageOwn = value; }
        }

        /// <summary>
        /// Gets or sets the number.
        /// </summary>
        /// <value>
        /// The number.
        /// </value>
        public int Number
        {
            get { return this.number; }
            set { this.number = value; }
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="BusinessException"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="inner">The inner.</param>
        public ApplicationException(string message, Exception inner)
            : base(message, inner)
        {
            this.messageOwn = message;
            if (message.Contains("ORA"))
            {
                this.Number = 1722;
            }
        }


    }
}
