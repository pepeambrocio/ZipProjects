﻿

namespace FlightJet.Application.Catalog
{
    using FlightJet.Application.DTO.Catalog;
    using System.Collections.Generic;

    public interface ICountryApplication
    {
        /// <summary>
        /// Gets all country.
        /// </summary>
        /// <returns> List CountryDto </returns>
        IList<CountryDTO> GetAllCountry();

        /// <summary>
        /// Finds the country by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>Country Dto</returns>
        CountryDTO FindCountryById(string id);

        /// <summary>
        /// Adds the country.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns>true or false</returns>
        bool AddCountry(CountryDTO entity);

        /// <summary>
        /// Deletes the country.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns>true or false</returns>
        bool DeleteCountry(CountryDTO entity);

        /// <summary>
        /// Updates the country.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns>true or false</returns>
        bool UpdateCountry(CountryDTO entity);

        /// <summary>
        /// Gets the actives country.
        /// </summary>
        /// <returns>true or false</returns>
        IList<CountryDTO> GetActivesCountry();
    }
}
