﻿

namespace FlightJet.Application.Catalog
{
    using System;
    using System.Collections.Generic;
    using FlightJet.Application.DTO.Catalog;
    using FlightJet.Persistence;
    using FlightJet.Persistence.Repositories.Catalog;
    using FlightJet.Domain.Catalog;
    using AutoMapper;
    using System.Linq;

    public class CountryApplication : ICountryApplication
    {
        /// <summary>
        /// The unit of work
        /// </summary>
        private readonly IUnitOfWork unitOfWork;

        /// <summary>
        /// The accountingAccount repository
        /// </summary>
        private readonly ICountryRepository countryRepository;

        public CountryApplication(IUnitOfWork unitOfWork, ICountryRepository countryRepository)
        {
            this.unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
            this.countryRepository = countryRepository ?? throw new ArgumentNullException(nameof(countryRepository));
        }

        public bool AddCountry(CountryDTO entity)
        {
            CountryEntity country = new CountryEntity();

            if (entity == null)
            {
                return false;
            }

            if (this.IsCountryCodeDuplicate(entity.CountryCode))
            {
                throw new ApplicationException("Regristo duplicado");
            }

            try
            {
                entity.Status = true;
                country = Mapper.Map<CountryEntity>(entity);
                this.countryRepository.Add(country);
                this.unitOfWork.Commit();

                return true;
            }
            catch (Exception exception)
            {
                throw new ApplicationException(exception.Message);
            }
        }

        public bool DeleteCountry(CountryDTO entity)
        {
            try
            {
                CountryEntity country = this.countryRepository.FindById(entity.CountryCode);

                if (country != null)
                {
                    /*
                    * Si se quiere hacer un borrado permanente de la DB
                    * se debe de usar la siguiente instrucción:
                    * this.countryRepository.Delete(country);
                    */

                    // Para borrado lógico
                    country.Status = false;
                    this.countryRepository.Update(country);
                    this.unitOfWork.Commit();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception exception)
            {
                throw new ApplicationException(exception.Message);
            }
        }

        public CountryDTO FindCountryById(string id)
        {
            try
            {
                CountryEntity country = this.countryRepository.FindById(id);
                CountryDTO countryDto = new CountryDTO();
                countryDto = Mapper.Map<CountryEntity, CountryDTO>(country);

                return countryDto;
            }
            catch (Exception exception)
            {
                throw new ApplicationException(exception.Message);
            }
        }

        public IList<CountryDTO> GetActivesCountry()
        {
            try
            {
                IList<CountryEntity> countryEntity = this.countryRepository.GetActiveCountry().ToList();
                IList<CountryDTO> countryDto = new List<CountryDTO>();
                countryDto = Mapper.Map<IList<CountryEntity>, IList<CountryDTO>>(countryEntity);

                return countryDto.OrderBy(c => c.CountryCode).ToList();
            }
            catch (Exception exception)
            {
                throw new ApplicationException(exception.Message);
            }
        }

        public IList<CountryDTO> GetAllCountry()
        {
            try
            {
                IList<CountryEntity> countryEntity = this.countryRepository.GetAll().ToList();
                IList<CountryDTO> countryDto = new List<CountryDTO>();

                countryDto = Mapper.Map<IList<CountryEntity>, IList<CountryDTO>>(countryEntity);
                return countryDto;
            }
            catch (Exception exception)
            {
                throw new ApplicationException(exception.Message);
            }
        }

        public bool UpdateCountry(CountryDTO entity)
        {
            try
            {
                CountryEntity country = this.countryRepository.FindById(entity.CountryCode);
                country.CountryName = entity.CountryName;
                country.CountryCodeShort = entity.CountryCodeShort;
                this.countryRepository.Update(country);
                this.unitOfWork.Commit();
                return true;
            }
            catch (Exception exception)
            {
                throw new ApplicationException(exception.Message);
            }
        }

        /// <summary>
        /// Determines whether [is country code duplicate] [the specified country code].
        /// </summary>
        /// <param name="countryCode">The country code.</param>
        /// <returns>true or false</returns>
        public bool IsCountryCodeDuplicate(string countryCode)
        {
            CountryEntity country = this.countryRepository.FindById(countryCode);
            return country != null ? true : false;
        }
    }
}
