﻿

namespace FlightJet.Application.Security
{
    using System;
    using System.Collections.Generic;
    using FlightJet.Application.DTO.Security;
    using FlightJet.Domain.Common;
    using FlightJet.Persistence;
    using FlightJet.Persistence.Repositories.Security;
    using FlightJet.Domain.Security;
    using FlightJet.Application.Common;

    public class UserApplication : IUserApplication
    {
        /// <summary>
        /// The unit of work
        /// </summary>
        private readonly IUnitOfWork unitOfWork;

        /// <summary>
        /// The accountingAccount repository
        /// </summary>
        private readonly IUserRepository userRepository;

        public UserApplication(IUnitOfWork unitOfWork, IUserRepository userRepository)
        {
            this.unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
            this.userRepository = userRepository ?? throw new ArgumentNullException(nameof(userRepository));
        }

        public UserDTO FindById(long id)
        {
            try
            {
                UserEntity user = this.userRepository.FindById(id);
                UserDTO userDto = new UserDTO
                {
                    UserID = user.UserID,
                    Email = user.Email,
                    UserName = user.UserName,
                    EmployeNo = user.EmployeNo,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    RoleCode = user.Role.RoleCode,
                    IsAdmin = user.IsAdmin,
                    UserDomain = Convert.ToBoolean(user.UserDomain),
                    Password = user.Password,
                    Status = user.Status
                };



                userDto.Role = new RoleDTO
                {
                    RoleCode = user.Role.RoleCode,
                    RoleName = user.Role.RoleName

                };
                return userDto;
            }
            catch (Exception exception)
            {
                throw new ApplicationException("Failed to retrieve records from database. See inner exception."
                    , exception);
            }
        }

        public UserDTO FindByUserName(string userName)
        {
            if (string.IsNullOrWhiteSpace(userName))
            {
                return null;
            }

            try
            {
                UserEntity user = this.userRepository.FindByUserName(userName);
                UserDTO userDto = new UserDTO();
                if (user != null)
                {
                    userDto.UserID = user.UserID;
                    userDto.Email = user.Email;
                    userDto.EmployeNo = user.EmployeNo;
                    userDto.IsAdmin = user.IsAdmin;
                    userDto.Password = user.Password;
                    userDto.UserDomain = Convert.ToBoolean(user.UserDomain);

                    userDto.Role = new RoleDTO
                    {
                        RoleCode = user.Role.RoleCode,
                        RoleName = user.Role.RoleName
                    };


                    foreach (var item in user.Role.RoleModulePermissions)
                    {
                        RoleModulePermissionDTO rmp = new RoleModulePermissionDTO();
                        rmp.Module = new ModuleDTO
                        {
                            ModuleCode = item.Module.ModuleCode,
                            MenuCode = item.Module.MenuCode,
                            ModuleName = item.Module.ModuleName,
                            ControllerName = item.Module.ControllerName
                        };

                        rmp.Permission = new PermissionDTO
                        {
                            PermissionCode = item.Permission.PermissionCode,
                            PermissionName = item.Permission.PermissionName
                        };

                        userDto.Role.RoleModulePermissions.Add(rmp);
                    }
                }

                return userDto;
            }
            catch (Exception exception)
            {
                throw new ApplicationException("Failed to find record.", exception);
            }
        }

        public UserDTO FindByUserNameEdit(string userName, long userId)
        {
            throw new NotImplementedException();
        }

        public IList<UserDTO> GetActivesUsers()
        {
            try
            {
                IList<UserEntity> userList = this.userRepository.GetActivesUsers();
                IList<UserDTO> userDtoList = new List<UserDTO>();
                //userDtoList = Mapper.Map<IList<UserEntity>, IList<UserDTO>>(userList);
                return userDtoList;
            }
            catch (Exception exception)
            {
                throw new ApplicationException("Failed to retrieve records from database. ", exception);
            }
        }

        public PagedResult<UserDTO> GetPagedUsers(FilterGrid filter)
        {
            try
            {
                FilterGrid filterData = new FilterGrid
                {
                    Offset = filter.Offset,
                    Limit = filter.Limit,
                    Search = filter.Search,
                    Sort = filter.Sort,
                    Order = filter.Order
                };
                IList<UserDTO> dtos = new List<UserDTO>();
                var paged = this.userRepository.GetPagedUsers(filterData);


                foreach (UserEntity user in paged.Results)
                {
                    dtos.Add(new UserDTO
                    {
                        UserID = user.UserID,
                        RoleCode = user.RoleCode,
                        UserName = user.UserName,
                        EmployeNo = user.EmployeNo,
                        FirstName = user.FirstName,
                        LastName = user.LastName,
                        Email = user.Email,
                        UserDomain = Convert.ToBoolean(user.UserDomain),
                        Password = user.Password,
                        IsAdmin = user.IsAdmin,
                        Status = user.Status
                    });
                }

                return new PagedResult<UserDTO>
                {
                    Results = dtos,
                    CurrentPage = 0,
                    PageSize = 0,
                    PageCount = paged.PageCount,
                    RowCount = paged.RowCount
                };
            }
            catch (Exception)
            {
                return new PagedResult<UserDTO>();
            }
        }

        public bool AddUser(UserDTO entity)
        {
            if (entity == null)
            {
                return false;
            }
            try
            {
                UserEntity userValid = this.userRepository.FindByUserName(entity.Email);
                if (userValid != null)
                {
                    throw new ApplicationException("Usuario ya existe.");
                }
                else
                {
                    UserEntity user = new UserEntity
                    {
                        UserID = entity.UserID,
                        UserName = entity.UserName,
                        Email = entity.Email,
                        EmployeNo = entity.EmployeNo,
                        FirstName = entity.FirstName,
                        LastName = entity.LastName,
                        RoleCode = entity.RoleCode,
                        Password = entity.Password,
                        Init = DateTime.Now,
                        UserDomain = entity.UserDomain,
                        IsAdmin = 1,
                        Status = 1
                    };

                    this.userRepository.Add(user);
                    this.unitOfWork.Commit();
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public bool DeleteUser(UserDTO entity)
        {
            UserEntity user = this.userRepository.FindById(entity.UserID);

            user.Status = 0;

            this.userRepository.Update(user);
            this.unitOfWork.Commit();
            return true;
        }

        public bool UpdateUser(UserDTO entity)
        {
            try
            {
                UserEntity user = this.userRepository.FindById(entity.UserID);

                user.Email = entity.Email;
                user.EmployeNo = entity.EmployeNo;
                user.Email = entity.Email;
                user.FirstName = entity.FirstName;
                user.LastName = entity.LastName;
                user.RoleCode = entity.RoleCode;
                user.IsAdmin = entity.IsAdmin;
                user.UserDomain = entity.UserDomain;
                user.Password = entity.Password;

                this.userRepository.Update(user);
                this.unitOfWork.Commit();
                return true;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public UserDTO UserAuthenticate(UserDTO user)
        {
            if (string.IsNullOrWhiteSpace(user.UserName))
            {
                return null;
            }

            try
            {
                UserEntity userEntity = this.userRepository.FindByUserName(user.UserName);
                UserDTO userDto = new UserDTO();
                if (userEntity != null)
                {
                    if (SecurityApplication.Decrypt(userEntity.Password) == user.Password)
                    {
                        userDto.UserID = userEntity.UserID;
                        userDto.Email = userEntity.Email;
                        userDto.UserName = userEntity.UserName;
                        userDto.EmployeNo = userEntity.EmployeNo;
                        userDto.IsAdmin = userEntity.IsAdmin;
                        userDto.Password = userEntity.Password;
                        userDto.UserDomain = Convert.ToBoolean(userEntity.UserDomain);

                        userDto.Role = new RoleDTO
                        {
                            RoleCode = userEntity.Role.RoleCode,
                            RoleName = userEntity.Role.RoleName
                        };


                        foreach (var item in userEntity.Role.RoleModulePermissions)
                        {
                            RoleModulePermissionDTO rmp = new RoleModulePermissionDTO();
                            rmp.Module = new ModuleDTO
                            {
                                ModuleCode = item.Module.ModuleCode,
                                MenuCode = item.Module.MenuCode,
                                ModuleName = item.Module.ModuleName,
                                ControllerName = item.Module.ControllerName
                            };

                            rmp.Permission = new PermissionDTO
                            {
                                PermissionCode = item.Permission.PermissionCode,
                                PermissionName = item.Permission.PermissionName
                            };

                            userDto.Role.RoleModulePermissions.Add(rmp);
                        }
                    }                    
                }

                return userDto;
            }
            catch (Exception exception)
            {
                throw new ApplicationException("Failed to find record.", exception);
            }
        }
    }
}
