﻿
namespace FlightJet.Application.Security
{
    using System;
    using System.Collections.Generic;
    using FlightJet.Application.DTO.Security;
    using FlightJet.Persistence;
    using FlightJet.Persistence.Repositories.Security;

    public class RoleApplication : IRoleApplication
    {
        /// <summary>
        /// The unit of work
        /// </summary>
        private readonly IUnitOfWork unitOfWork;

        private readonly IRoleRepository roleRepository;

        public RoleApplication(IUnitOfWork unitOfWork, IRoleRepository roleRepository)
        {
            this.unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
            this.roleRepository = roleRepository ?? throw new ArgumentNullException(nameof(roleRepository));
        }

        public List<RoleDTO> GetAll()
        {
            try
            {
                List<RoleDTO> lstdto = new List<RoleDTO>();
                var entities = this.roleRepository.GetAll();
                foreach (var item in entities)
                {
                    lstdto.Add(new RoleDTO
                    {
                        RoleCode = item.RoleCode,
                        RoleName = item.RoleName
                    });
                }

                return lstdto;
            }
            catch (Exception exception)
            {
                throw new ApplicationException($"Failed to retrieve records from database. See inner exception. {exception}");
            }
        }
    }
}
