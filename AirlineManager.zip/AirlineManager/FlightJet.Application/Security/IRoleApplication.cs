﻿



namespace FlightJet.Application.Security
{
    using FlightJet.Application.DTO.Security;
    using System.Collections.Generic;
    public interface IRoleApplication
    {
        List<RoleDTO> GetAll();
    }
}
