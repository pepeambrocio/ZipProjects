﻿

namespace FlightJet.Application.Security
{
    using FlightJet.Application.DTO.Security;
    using FlightJet.Domain.Common;
    using System.Collections.Generic;

    public interface IUserApplication
    {
        /// <summary>
        /// Adds the user.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        bool AddUser(UserDTO entity);

        /// <summary>
        /// Deletes the user.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        bool DeleteUser(UserDTO entity);

        /// <summary>
        /// Updates the user.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        bool UpdateUser(UserDTO entity);

        /// <summary>
        /// Finds by the entity's identifier.
        /// </summary>
        /// <param name="id">The entity's identifier.</param>
        /// <returns>FuelConcept Entity.</returns>
        UserDTO FindById(long id);

        /// <summary>
        /// FindByUserName
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        UserDTO FindByUserName(string userName);

        /// <summary>
        /// FindByUserNameEdit
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        UserDTO FindByUserNameEdit(string userName, long userId);

        /// <summary>
        /// Users the authenticate.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <returns></returns>
        UserDTO UserAuthenticate(UserDTO user);

        /// <summary>
        /// Gets the Actives FuelConcepts.
        /// </summary>
        /// <returns>FuelConcepts marked as Actives.</returns>
        IList<UserDTO> GetActivesUsers();

        /// <summary>
        /// Gets the paged users.
        /// </summary>
        /// <param name="filterDTO">The filter dto.</param>
        /// <returns></returns>
        PagedResult<UserDTO> GetPagedUsers(FilterGrid filter);
    }
}
