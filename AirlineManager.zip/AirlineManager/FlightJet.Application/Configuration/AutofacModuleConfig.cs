﻿
namespace FlightJet.Application.Configuration
{

    using FlightJet.Persistence;
    using FlightJet.Persistence.Repositories.Itinerary;
    using Autofac;
    using System.Reflection;

    public class AutofacModuleConfig : Autofac.Module
    {
        /// <summary>
        /// Override to add registrations to the container.
        /// </summary>
        /// <param name="builder">The builder through which components can be
        /// registered.</param>
        /// <remarks>
        /// Note that the ContainerBuilder parameter is unique to this module.
        /// </remarks>
        protected override void Load(ContainerBuilder builder)
        {
            // The generic ILogger<TCategoryName> service was added to the ServiceCollection by ASP.NET Core.
            // It was then registered with Autofac using the Populate method in ConfigureServices.


            // Register the project Business
            builder.RegisterAssemblyTypes(Assembly.Load("FlightJet.Application"))
                .Where(t => t.Name.EndsWith("Application", System.StringComparison.Ordinal))
                .AsImplementedInterfaces()
                .InstancePerLifetimeScope();

            // Register the project Dal
            builder.RegisterAssemblyTypes(Assembly.Load("FlightJet.Persistence"))
              .Where(t => t.Name.EndsWith("Repository", System.StringComparison.Ordinal))
              .AsImplementedInterfaces()
              .InstancePerLifetimeScope();

            // Register the interface and the class             

            builder.RegisterType<UnitOfWork>().As<IUnitOfWork>().InstancePerLifetimeScope();
            builder.RegisterType<DbFactory>().As<IDbFactory>().InstancePerLifetimeScope();
            builder.RegisterType<ItineraryRepository>().As<IItineraryRepository>().InstancePerLifetimeScope();
        }
    }
}
