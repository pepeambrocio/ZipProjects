﻿


namespace FlightJet.Application.Airport
{
    using System;
    using System.Collections.Generic;
    using FlightJet.Application.DTO.Airport;
    using FlightJet.Persistence;
    using FlightJet.Persistence.Repositories.Airport;
    using FlightJet.Domain.Airport;
    using AutoMapper;
    using System.Linq;

    public class AirportApplication : IAirportApplication
    {
        /// <summary>
        /// The unit of work
        /// </summary>
        private readonly IUnitOfWork unitOfWork;

        /// <summary>
        /// The accountingAccount repository
        /// </summary>
        private readonly IAirportRepository airportRepository;

        public AirportApplication(IUnitOfWork unitOfWork, IAirportRepository airportRepository)
        {
            this.unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
            this.airportRepository = airportRepository ?? throw new ArgumentNullException(nameof(airportRepository));
        }

        public bool AddAirport(AirportDTO entity)
        {
            if (this.IsDuplicate(entity.StationCode))
            {
                throw new ApplicationException("Registro duplicado");
            }
            try
            {
                AirportEntity airportModel = new AirportEntity
                {
                    AirportGroupCode = entity.AirportGroupCode,
                    ClosingTime = entity.ClosingTime,                    
                    CountryCode = entity.CountryCode,
                    OpeningTime = entity.OpeningTime,
                    StationCode = entity.StationCode,
                    StationName = entity.StationName,
                    Status = true
                };
                airportModel.Status = true;
                this.airportRepository.Add(airportModel);
                this.unitOfWork.Commit();
                return true;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public bool DeleteAirport(AirportDTO entity)
        {
            try
            {
                AirportEntity airportModel = this.airportRepository.FindById(entity.StationCode);
                airportModel.Status = false;
                this.airportRepository.Update(airportModel);
                this.unitOfWork.Commit();
                return true;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public AirportDTO FindAirportById(string id)
        {
            try
            {
                AirportEntity airportModel = this.airportRepository.FindById(id);
                AirportDTO airportDTO = Mapper.Map<AirportEntity, AirportDTO>(airportModel);
                return airportDTO;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public IList<AirportDTO> GetActivesAirports()
        {
            try
            {
                IList<AirportEntity> airportModel = this.airportRepository.GetActivesAirports();
                IList<AirportDTO> airportDTO = Mapper.Map<IList<AirportEntity>, IList<AirportDTO>>(airportModel);
                return airportDTO.OrderBy(c => c.StationCode).ToList();
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public IList<AirportDTO> GetAllAirport()
        {
            try
            {
                IList<AirportEntity> airportsModel = this.airportRepository.GetAll();
                IList<AirportDTO> airportDTO = new List<AirportDTO>();
                foreach (var item in airportsModel)
                {
                    airportDTO.Add(new AirportDTO {
                        StationCode = item.StationCode,
                        StationName = item.StationName,
                        AirportGroupCode = item.AirportGroupCode,
                        CountryCode = item.CountryCode,
                        ClosingTime = item.ClosingTime,
                        OpeningTime = item.OpeningTime
                    });
                }                
                return airportDTO.ToList();
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public bool PhysicalDeleteAirport(AirportDTO entity)
        {
            try
            {
                AirportEntity airportModel = Mapper.Map<AirportDTO, AirportEntity>(entity);
                this.airportRepository.Delete(airportModel);
                return true;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        public bool UpdateAirport(AirportDTO entity)
        {
            try
            {
                AirportEntity airportModel = Mapper.Map<AirportDTO, AirportEntity>(entity);
                airportModel.Status = true;
                this.airportRepository.Update(airportModel);
                this.unitOfWork.Commit();
                return true;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        /// <summary>
        /// Determines whether entity Code duplicate is.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private bool IsDuplicate(string id)
        {
            AirportEntity entity = this.airportRepository.FindById(id);
            return entity != null ? true : false;
        }
    }
}
