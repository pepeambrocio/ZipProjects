﻿
namespace FlightJet.Application.Airport
{
    using FlightJet.Application.DTO.Airport;
    using System;
    using System.Collections.Generic;
    using System.Text;


    public interface IAirplaneApplication
    {        
        IList<AirplaneDTO> GetActivesAirplanes();
    }
}
