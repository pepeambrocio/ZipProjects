﻿



namespace FlightJet.Application.Airport
{
    using FlightJet.Application.DTO.Airport;
    using System.Collections.Generic;

    public interface IAirportApplication
    {
        /// <summary>
        /// Gets all airport.
        /// </summary>
        /// <returns>List of Airports.</returns>
        IList<AirportDTO> GetAllAirport();

        /// <summary>
        /// Finds the AirportDto by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>Entity AirportDto.</returns>
        AirportDTO FindAirportById(string id);

        /// <summary>
        /// Adds the AirportDto.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns>true if was added else false</returns>
        bool AddAirport(AirportDTO entity);

        /// <summary>
        /// Deletes the AirportDto.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns>true if was deleted else false</returns>
        bool DeleteAirport(AirportDTO entity);

        /// <summary>
        /// Physical Delete
        /// </summary>
        /// <param name="entity">The entity</param>
        /// <returns>Boolean</returns>
        bool PhysicalDeleteAirport(AirportDTO entity);

        /// <summary>
        /// Updates the AirportDto.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns>true if was updated else false</returns>
        bool UpdateAirport(AirportDTO entity);

        /// <summary>
        /// Gets the Actives airports.
        /// </summary>
        /// <returns>Airports Actives.</returns>
        IList<AirportDTO> GetActivesAirports();
    }
}
