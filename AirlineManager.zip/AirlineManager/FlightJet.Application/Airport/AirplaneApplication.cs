﻿

namespace FlightJet.Application.Airport
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using FlightJet.Application.DTO.Airport;
    using FlightJet.Domain.Airport;
    using FlightJet.Persistence;
    using FlightJet.Persistence.Repositories.Airport;

    public class AirplaneApplication : IAirplaneApplication
    {
        /// <summary>
        /// The unit of work
        /// </summary>
        private readonly IUnitOfWork unitOfWork;

        /// <summary>
        /// The accountingAccount repository
        /// </summary>
        private readonly IAirplaneRepository airplaneRepository;

        public AirplaneApplication(IUnitOfWork unitOfWork, IAirplaneRepository airplaneRepository)
        {
            this.unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
            this.airplaneRepository = airplaneRepository ?? throw new ArgumentNullException(nameof(airplaneRepository));
        }

        public IList<AirplaneDTO> GetActivesAirplanes()
        {
            try
            {
                IList<AirplaneEntity> airportsModel = this.airplaneRepository.GetActivesAirplanes();
                IList<AirplaneDTO> airplanes = new List<AirplaneDTO>();
                foreach (var item in airportsModel)
                {
                    airplanes.Add(new AirplaneDTO {
                        EquipmentNumber = item.EquipmentNumber,
                        AirplaneModel = item.AirplaneModel,
                        SerialNumber = item.SerialNumber
                    });
                }

                return airplanes;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }
    }
}
