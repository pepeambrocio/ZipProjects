﻿
namespace FlightJet.Application.Airport
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using FlightJet.Application.DTO.Airport;
    using FlightJet.Domain.Airport;
    using FlightJet.Domain.Common;
    using FlightJet.Persistence;
    using FlightJet.Persistence.Repositories.Airport;

    public class BaggageDocumentApplication : IBaggageDocumentApplication
    {
        /// <summary>
        /// The unit of work
        /// </summary>
        private readonly IUnitOfWork unitOfWork;

        /// <summary>
        /// The baggage document repository
        /// </summary>
        private readonly IBaggageDocumentRepository baggageDocumentRepository;

        public BaggageDocumentApplication(IUnitOfWork unitOfWork, IBaggageDocumentRepository baggageDocumentRepository)
        {
            this.unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
            this.baggageDocumentRepository = baggageDocumentRepository ?? throw new ArgumentNullException(nameof(baggageDocumentRepository));
        }

        public bool AddBaggageDocument(BaggageDocumentDTO entity)
        {
            BaggageDocumentEntity baggageDocument = new BaggageDocumentEntity();

            if (entity == null)
            {
                return false;
            }

            if (this.IsBaggageDocumentDuplicate(entity.PassengerID, entity.AirlineCode, entity.FlightNumber, entity.ItineraryKey))
            {
                throw new ApplicationException("Regristro duplicado");
            }

            try
            {
                int passengerId = this.baggageDocumentRepository.GetSequenceBaggageDocument(entity.AirlineCode, entity.FlightNumber, entity.ItineraryKey);
                passengerId++;

                baggageDocument.PassengerID  = passengerId;
                baggageDocument.AirlineCode  = entity.AirlineCode;
                baggageDocument.FlightNumber = entity.FlightNumber;
                baggageDocument.ItineraryKey = entity.ItineraryKey;
                baggageDocument.FirstName    = entity.FirstName ?? string.Empty;
                baggageDocument.LastName     = entity.LastName ?? string.Empty;
                baggageDocument.Piece        = entity.Piece;
                baggageDocument.Weight       = entity.Weight ?? 0;                
                this.baggageDocumentRepository.Add(baggageDocument);
                this.unitOfWork.Commit();

                return true;
            }
            catch (Exception exception)
            {
                throw new ApplicationException(exception.Message);
            }
        }

        public bool DeleteBaggageDocument(BaggageDocumentDTO entity)
        {
            try
            {
                BaggageDocumentEntity baggageDocumentEntity = this.baggageDocumentRepository
                    .FindBaggageDocument(entity.PassengerID, entity.AirlineCode, entity.FlightNumber, entity.ItineraryKey);

                if (baggageDocumentEntity != null)
                {
                    /*
                    * Si se quiere hacer un borrado permanente de la DB
                    * se debe de usar la siguiente instrucción:
                    * this.countryRepository.Delete(country);
                    */

                    // Para borrado lógico

                    this.baggageDocumentRepository.Delete(baggageDocumentEntity);
                    this.unitOfWork.Commit();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception exception)
            {
                throw new ApplicationException(exception.Message);
            }
        }

        public BaggageDocumentDTO FindBaggageDocument(BaggageDocumentDTO entity)
        {
            try
            {
                BaggageDocumentEntity baggageDocumentEntity = this.baggageDocumentRepository
                    .FindBaggageDocument(entity.PassengerID, entity.AirlineCode, entity.FlightNumber, entity.ItineraryKey);

                BaggageDocumentDTO baggageDocumentDTO = new BaggageDocumentDTO{
                    PassengerID  = baggageDocumentEntity.PassengerID,
                    AirlineCode  = baggageDocumentEntity.AirlineCode,
                    FlightNumber = baggageDocumentEntity.FlightNumber,
                    ItineraryKey = baggageDocumentEntity.ItineraryKey,
                    FirstName    = baggageDocumentEntity.FirstName,
                    LastName     = baggageDocumentEntity.LastName,
                    Sequence     = baggageDocumentEntity.PassengerID,
                    Piece        = baggageDocumentEntity.Piece,
                    Weight       = baggageDocumentEntity.Weight

                };                

                return baggageDocumentDTO;
            }
            catch (Exception exception)
            {
                throw new ApplicationException(exception.Message);
            }
        }

        public PagedResult<BaggageDocumentDTO> GetPagedResult(int page, int pageSize, 
            string airlineCode, string flightNumber, string itineraryKey)
        {
            try
            {
                var paged = baggageDocumentRepository.GetPagedResult(page, pageSize, airlineCode,
                    flightNumber, itineraryKey);

                List<BaggageDocumentDTO> lst = new List<BaggageDocumentDTO>();

                foreach (var item in paged.Results)
                {
                    lst.Add(
                        new BaggageDocumentDTO
                        {
                            PassengerID  = item.PassengerID,
                            AirlineCode  = item.AirlineCode,
                            FlightNumber = item.FlightNumber,
                            ItineraryKey = item.ItineraryKey,
                            FirstName    = item.FirstName,
                            LastName     = item.LastName,
                            Sequence     = item.PassengerID,
                            Piece        = item.Piece,
                            Weight       = item.Weight
                        });
                }
                return new PagedResult<BaggageDocumentDTO>
                {
                    Results     = lst,
                    CurrentPage = page,
                    PageSize    = pageSize,
                    PageCount   = paged.PageCount,
                    RowCount    = paged.RowCount
                };
            }
            catch (Exception ex)
            {
                throw new ApplicationException($"Error to get Paged : {ex?.InnerException}");
            }
        }

        public PagedResult<BaggageDocumentDTO> ItineraryCustomSearchFunc(string filter, int initialPage, 
            int pageSize, string airlineCode, string flightNumber, string itineraryKey)
        {
            try
            {
                var paged = baggageDocumentRepository.GetPagedResult(initialPage, pageSize, airlineCode,
                    flightNumber, itineraryKey);

                List<BaggageDocumentDTO> lst = new List<BaggageDocumentDTO>();

                foreach(var item in paged.Results)
                {
                    lst.Add(
                        new BaggageDocumentDTO
                        {
                            PassengerID = item.PassengerID,
                            AirlineCode = item.AirlineCode,
                            FlightNumber = item.FlightNumber,
                            ItineraryKey = item.ItineraryKey,
                            FirstName = item.FirstName,
                            LastName = item.LastName,
                            Sequence = item.PassengerID,
                            Piece = item.Piece,
                            Weight = item.Weight
                        });
                }
                return new PagedResult<BaggageDocumentDTO>
                {
                    Results = lst,
                    CurrentPage = initialPage,
                    PageSize = pageSize,
                    PageCount = paged.PageCount,
                    RowCount = paged.RowCount
                };
            }
            catch (Exception ex)
            {
                throw new ApplicationException($"Error to get Paged : {ex?.InnerException}");
            }
        }

        public bool UpdateBaggageDocument(BaggageDocumentDTO entity)
        {
            try
            {
                BaggageDocumentEntity baggageDocumentEntity = this.baggageDocumentRepository
                   .FindBaggageDocument(entity.PassengerID, entity.AirlineCode, entity.FlightNumber, entity.ItineraryKey);


                baggageDocumentEntity.FirstName = entity.FirstName;
                baggageDocumentEntity.LastName = entity.LastName;
                baggageDocumentEntity.Piece = entity.Piece;
                baggageDocumentEntity.Weight = entity.Weight;                

                this.baggageDocumentRepository.Update(baggageDocumentEntity);
                this.unitOfWork.Commit();
                return true;
            }
            catch (Exception exception)
            {
                throw new ApplicationException(exception.Message);
            }
        }

        public bool IsBaggageDocumentDuplicate(int passengerID, string airlineCode, string flightNumber, string itineraryKey)
        {
            BaggageDocumentEntity baggageDocument = this.baggageDocumentRepository
                .FindBaggageDocument(passengerID, airlineCode, flightNumber, itineraryKey);
            return baggageDocument != null ? true : false;
        }
    }
}
