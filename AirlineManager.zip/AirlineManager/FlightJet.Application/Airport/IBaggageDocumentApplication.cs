﻿

namespace FlightJet.Application.Airport
{
    using FlightJet.Application.DTO.Airport;
    using FlightJet.Domain.Common;
    using System;
    using System.Collections.Generic;
    using System.Text;

    public interface IBaggageDocumentApplication
    {

        /// <summary>
        /// Finds the baggage document.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        BaggageDocumentDTO FindBaggageDocument(BaggageDocumentDTO entity);


        /// <summary>
        /// Adds the i baggage document.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        bool AddBaggageDocument(BaggageDocumentDTO entity);


        /// <summary>
        /// Deletes the baggage document.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        bool DeleteBaggageDocument(BaggageDocumentDTO entity);


        /// <summary>
        /// Updates the baggage document.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        bool UpdateBaggageDocument(BaggageDocumentDTO entity);

        PagedResult<BaggageDocumentDTO> GetPagedResult(int page, int pageSize,
             string airlineCode, string flightNumber, string itineraryKey);

        PagedResult<BaggageDocumentDTO> ItineraryCustomSearchFunc(string filter, int initialPage, int pageSize,
             string airlineCode, string flightNumber, string itineraryKey);
    }
}
