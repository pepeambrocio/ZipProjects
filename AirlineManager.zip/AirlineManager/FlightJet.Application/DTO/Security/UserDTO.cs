﻿

namespace FlightJet.Application.DTO.Security
{
    using System;
    public class UserDTO
    {
        public long UserID { get; set; }

        public string RoleCode { get; set; }

        public string UserName { get; set; }
       
        public string EmployeNo { get; set; }
        
        public string FirstName { get; set; }
        
        public string LastName { get; set; }
       
        public string Email { get; set; }

        public bool UserDomain { get; set; }

        public string Password { get; set; }

        public int IsAdmin { get; set; }

        public DateTime Init { get; set; }

        public int Status { get; set; }

        public virtual RoleDTO Role { get; set; }
    }
}