﻿

namespace FlightJet.Application.DTO.Security
{
    using System.Collections.Generic;
    public class RoleDTO
    {
        public RoleDTO()
        {
            RoleModulePermissions = new HashSet<RoleModulePermissionDTO>();
            Users = new HashSet<UserDTO>();
        }
        
        public string RoleCode { get; set; }

        public string RoleName { get; set; }

        public virtual ICollection<RoleModulePermissionDTO> RoleModulePermissions { get; set; }

        public virtual ICollection<UserDTO> Users { get; set; }
    }
}