﻿

namespace FlightJet.Application.DTO.Security
{
    using System;
    using System.Collections.Generic;

    public class ModuleDTO
    {
        public ModuleDTO()
        {
            RoleModulePermissions = new HashSet<RoleModulePermissionDTO>();
        }
        
        public string ModuleCode { get; set; }

        public string ModuleName { get; set; }

        public string MenuCode { get; set; }

        public string ControllerName { get; set; }
        
        public virtual ICollection<RoleModulePermissionDTO> RoleModulePermissions { get; set; }
    }
}
