﻿
namespace FlightJet.Application.DTO.Security
{
    using System.Collections.Generic;
    public class PermissionDTO
    {
        public PermissionDTO()
        {
            RoleModulePermissions = new HashSet<RoleModulePermissionDTO>();
        }

        public string PermissionCode { get; set; }
        
        public string PermissionName { get; set; }
        
        public virtual ICollection<RoleModulePermissionDTO> RoleModulePermissions { get; set; }
    }
}