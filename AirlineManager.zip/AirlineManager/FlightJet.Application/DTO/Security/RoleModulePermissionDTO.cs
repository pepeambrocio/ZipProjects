﻿namespace FlightJet.Application.DTO.Security
{
    public class RoleModulePermissionDTO
    {
        public string RoleCode { get; set; }
        
        public string ModuleCode { get; set; }

        public string PermissionCode { get; set; }

        public virtual ModuleDTO Module { get; set; }

        public virtual PermissionDTO Permission { get; set; }

        public virtual RoleDTO Role { get; set; }
    }
}