﻿
namespace FlightJet.Application.DTO.Itinerary
{
    using System;
    public class ItineraryDTO
    {
        public int Sequence { get; set; }
        
        public string AirlineCode { get; set; }

        public string FlightNumber { get; set; }

        public string ItineraryKey { get; set; }

        public string EquipmentNumber { get; set; }

        public DateTime DepartureDate { get; set; }

        public string DepartureStation { get; set; }

        public DateTime ArrivalDate { get; set; }

        public string ArrivalStation { get; set; }        
    }
}
