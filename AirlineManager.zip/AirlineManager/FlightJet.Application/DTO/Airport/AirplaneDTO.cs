﻿
namespace FlightJet.Application.DTO.Airport
{
    using System;
    using System.Collections.Generic;
    using System.Text;


    public class AirplaneDTO
    {
        public string EquipmentNumber { get; set; }

        public string AirlineCode { get; set; }
        
        public string AirplaneModel { get; set; }

        public decimal MaximumTakeoffWeight { get; set; }

        public decimal WeightInPound { get; set; }

        public decimal WeightInTonnes { get; set; }

        public string SerialNumber { get; set; }
        
        public decimal EmptyOperatingWeight { get; set; }

        public decimal FilmingMaximumWeight { get; set; }

        public decimal TakeoffWeightInTonnes { get; set; }
      
        public decimal GroupWeight { get; set; }
       
        public decimal MaximumLandingWeight { get; set; }
       
        public decimal MaximumZeroFuelWeight { get; set; }

        public int PassengerCapacity { get; set; }

        public int CrewCapacity { get; set; }
        
        public decimal Magnitude { get; set; }

        public bool Status { get; set; }
    }
}
