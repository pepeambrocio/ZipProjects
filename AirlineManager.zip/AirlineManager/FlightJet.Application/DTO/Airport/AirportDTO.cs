﻿


namespace FlightJet.Application.DTO.Airport
{
    using FlightJet.Application.DTO.Catalog;
    using System;
    public class AirportDTO
    {
        public string StationCode { get; set; }
       
        public string StationName { get; set; }
        
        public string CountryCode { get; set; }

        public TimeSpan? OpeningTime { get; set; }

        public TimeSpan? ClosingTime { get; set; }
        
        public string AirportGroupCode { get; set; }

        public bool Status { get; set; }

        public virtual CountryDTO Country { get; set; }
    }
}
