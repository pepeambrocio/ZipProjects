﻿

namespace FlightJet.Application.DTO.Catalog
{
    using System;
    public class CountryDTO
    {        
        public string CountryCode { get; set; }
        
        public string CountryCodeShort { get; set; }
        
        public string CountryName { get; set; }

        public bool Status { get; set; }
        
    }
}
